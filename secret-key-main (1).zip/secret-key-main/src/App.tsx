import React, { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DataProvider, useData } from './context/DataContext';
import { AuthWelcomePage } from './pages/AuthWelcomePage';
import { CompliancePage } from './pages/CompliancePage';
import { DashboardPage } from './pages/DashboardPage';
import { DeveloperToolsPage } from './pages/DeveloperToolsPage';
import { FindingsPage } from './pages/FindingsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { RepositoriesPage } from './pages/RepositoriesPage';
import { ScansPage } from './pages/ScansPage';
import { SettingsPage } from './pages/SettingsPage';
import { TeamPage } from './pages/TeamPage';

function AppContent() {
  const { isAuthenticated } = useData();
  const [activePage, setActivePage] = useState<string>('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [findingsRepoFilter, setFindingsRepoFilter] = useState<string | undefined>(undefined);

  // If user is not authenticated, display the Welcome / Login / Signup page first
  if (!isAuthenticated) {
    return <AuthWelcomePage />;
  }

  const handleNavigate = (page: string) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateFindingsForRepo = (repoName: string) => {
    setFindingsRepoFilter(repoName);
    setActivePage('findings');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="flex h-screen bg-slate-950 text-slate-100 font-sans antialiased overflow-hidden">
      {/* Sidebar Navigation */}
      <Sidebar
        currentPage={activePage}
        onNavigate={(page) => {
          if (page !== 'findings') {
            setFindingsRepoFilter(undefined);
          }
          handleNavigate(page);
        }}
        isOpen={isMobileSidebarOpen}
        onToggle={() => setIsMobileSidebarOpen((prev) => !prev)}
      />

      {/* Main Layout Container */}
      <div className="flex-1 flex flex-col min-w-0 h-full overflow-hidden">
        {/* Top Header */}
        <Header
          currentPage={activePage}
          onNavigate={handleNavigate}
          onToggleMobileSidebar={() => setIsMobileSidebarOpen((prev) => !prev)}
        />

        {/* Scrollable Page Content */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-slate-950/70">
          <div className="max-w-7xl mx-auto pb-12">
            {activePage === 'dashboard' && <DashboardPage onNavigate={handleNavigate} />}

            {activePage === 'findings' && (
              <FindingsPage initialRepoFilter={findingsRepoFilter} />
            )}

            {activePage === 'repositories' && (
              <RepositoriesPage
                onNavigateFindingsForRepo={handleNavigateFindingsForRepo}
                onNavigateScans={() => handleNavigate('scans')}
              />
            )}

            {activePage === 'scans' && (
              <ScansPage onNavigateFindingsForRepo={handleNavigateFindingsForRepo} />
            )}

            {activePage === 'compliance' && <CompliancePage />}

            {activePage === 'team' && <TeamPage />}

            {activePage === 'developer-tools' && <DeveloperToolsPage />}

            {activePage === 'notifications' && (
              <NotificationsPage
                onNavigateFinding={() => {
                  handleNavigate('findings');
                }}
              />
            )}

            {activePage === 'settings' && <SettingsPage />}
          </div>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <DataProvider>
      <AppContent />
    </DataProvider>
  );
}


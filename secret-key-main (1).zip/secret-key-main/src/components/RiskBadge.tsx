import React from 'react';
import { RiskLevel } from '../types';

interface RiskBadgeProps {
  level: RiskLevel;
  className?: string;
  size?: 'sm' | 'md';
}

export const RiskBadge: React.FC<RiskBadgeProps> = ({ level, className = '', size = 'sm' }) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm font-semibold';

  switch (level) {
    case 'Critical':
      return (
        <span
          id={`risk-badge-${level.toLowerCase()}`}
          className={`inline-flex items-center gap-1.5 font-medium rounded-md border border-rose-500/30 bg-rose-500/10 text-rose-400 dark:text-rose-400 ${sizeClasses} ${className}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
          Critical
        </span>
      );
    case 'High':
      return (
        <span
          id={`risk-badge-${level.toLowerCase()}`}
          className={`inline-flex items-center gap-1.5 font-medium rounded-md border border-amber-500/30 bg-amber-500/10 text-amber-400 dark:text-amber-400 ${sizeClasses} ${className}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
          High
        </span>
      );
    case 'Medium':
      return (
        <span
          id={`risk-badge-${level.toLowerCase()}`}
          className={`inline-flex items-center gap-1.5 font-medium rounded-md border border-yellow-500/30 bg-yellow-500/10 text-yellow-400 dark:text-yellow-400 ${sizeClasses} ${className}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-yellow-500" />
          Medium
        </span>
      );
    case 'Low':
    default:
      return (
        <span
          id={`risk-badge-${level.toLowerCase()}`}
          className={`inline-flex items-center gap-1.5 font-medium rounded-md border border-blue-500/30 bg-blue-500/10 text-blue-400 dark:text-blue-400 ${sizeClasses} ${className}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-blue-400" />
          Low
        </span>
      );
  }
};

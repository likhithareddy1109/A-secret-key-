import React from 'react';
import { FindingStatus } from '../types';

interface StatusBadgeProps {
  status: FindingStatus;
  className?: string;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, className = '', size = 'sm' }) => {
  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-sm font-semibold';

  switch (status) {
    case 'Open':
      return (
        <span
          id={`status-badge-open`}
          className={`inline-flex items-center gap-1.5 font-medium rounded-md border border-rose-500/20 bg-rose-500/10 text-rose-300 ${sizeClasses} ${className}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
          Open
        </span>
      );
    case 'Reviewing':
      return (
        <span
          id={`status-badge-reviewing`}
          className={`inline-flex items-center gap-1.5 font-medium rounded-md border border-amber-500/20 bg-amber-500/10 text-amber-300 ${sizeClasses} ${className}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          Reviewing
        </span>
      );
    case 'Resolved':
      return (
        <span
          id={`status-badge-resolved`}
          className={`inline-flex items-center gap-1.5 font-medium rounded-md border border-emerald-500/20 bg-emerald-500/10 text-emerald-400 ${sizeClasses} ${className}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          Resolved
        </span>
      );
    case 'False Positive':
      return (
        <span
          id={`status-badge-false-positive`}
          className={`inline-flex items-center gap-1.5 font-medium rounded-md border border-slate-500/20 bg-slate-500/10 text-slate-400 ${sizeClasses} ${className}`}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
          False Positive
        </span>
      );
    default:
      return null;
  }
};

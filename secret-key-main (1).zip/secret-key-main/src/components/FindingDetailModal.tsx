import React, { useState } from 'react';
import {
  AlertTriangle,
  Calendar,
  CheckCircle2,
  Clock,
  Code2,
  Copy,
  ExternalLink,
  FileCode,
  Fingerprint,
  GitCommit,
  RotateCcw,
  Shield,
  ShieldAlert,
  User,
  X,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { FindingStatus, SecretFinding } from '../types';
import { RiskBadge } from './RiskBadge';
import { StatusBadge } from './StatusBadge';

interface FindingDetailModalProps {
  finding: SecretFinding | null;
  onClose: () => void;
}

export const FindingDetailModal: React.FC<FindingDetailModalProps> = ({ finding, onClose }) => {
  const { updateFindingStatus, canResolveFindings } = useData();
  const [statusNotes, setStatusNotes] = useState('');
  const [copiedFingerprint, setCopiedFingerprint] = useState(false);
  const [copiedMasked, setCopiedMasked] = useState(false);

  if (!finding) return null;

  const handleStatusChange = (newStatus: FindingStatus) => {
    updateFindingStatus(finding.id, newStatus, statusNotes.trim() || undefined);
    setStatusNotes('');
  };

  const handleCopyFingerprint = () => {
    navigator.clipboard.writeText(finding.fingerprint);
    setCopiedFingerprint(true);
    setTimeout(() => setCopiedFingerprint(false), 2000);
  };

  const handleCopyMasked = () => {
    navigator.clipboard.writeText(finding.maskedPreview);
    setCopiedMasked(true);
    setTimeout(() => setCopiedMasked(false), 2000);
  };

  return (
    <div
      id="finding-detail-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs overflow-y-auto"
    >
      <div
        id={`finding-modal-${finding.id}`}
        className="w-full max-w-3xl my-8 bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-start justify-between gap-4 bg-slate-950/40">
          <div>
            <div className="flex items-center gap-3 mb-2 flex-wrap">
              <span className="font-mono text-sm font-bold text-cyan-400 bg-cyan-950/50 border border-cyan-800/40 px-2.5 py-0.5 rounded-md">
                {finding.id}
              </span>
              <RiskBadge level={finding.riskLevel} />
              <StatusBadge status={finding.status} />
              <span className="text-xs text-slate-400 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                Detected: {finding.detectedDate}
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-rose-400" />
              {finding.secretType}
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Found in repository{' '}
              <span className="font-mono text-slate-200 font-medium">{finding.repoName}</span>
            </p>
          </div>

          <button
            id="finding-modal-close-btn"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm">
          {/* Masked Secret Section */}
          <div className="bg-slate-950 border border-rose-900/30 rounded-xl p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold uppercase tracking-wider text-rose-400 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" />
                Masked Secret Preview (Zero Raw Secret Storage Guarantee)
              </span>
              <button
                id="copy-masked-secret-btn"
                onClick={handleCopyMasked}
                className="text-xs text-slate-400 hover:text-cyan-400 flex items-center gap-1 transition"
              >
                <Copy className="w-3 h-3" />
                {copiedMasked ? 'Copied' : 'Copy Mask'}
              </button>
            </div>
            <div className="font-mono text-slate-200 bg-slate-900/90 px-3 py-2.5 rounded-lg border border-slate-800 text-xs sm:text-sm break-all select-all flex items-center justify-between">
              <span>{finding.maskedPreview}</span>
            </div>
            <p className="text-[11px] text-slate-400 mt-2">
              Security Compliance Policy: Raw credentials, API keys, or private tokens are never stored, logged, or retained in database tables or client state.
            </p>
          </div>

          {/* Location & Metadata Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-2.5">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <FileCode className="w-3.5 h-3.5 text-cyan-400" />
                File & Location
              </h4>
              <div className="font-mono text-xs text-slate-200 bg-slate-900 px-2.5 py-1.5 rounded border border-slate-800 break-all">
                {finding.fileName} : line {finding.lineNumber}
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                <span>Detection Engine:</span>
                <span className="text-slate-300 font-medium">{finding.detectionMethod}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Confidence Rating:</span>
                <span className="text-emerald-400 font-semibold">{finding.confidence}% Confidence</span>
              </div>
            </div>

            <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-2.5">
              <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <GitCommit className="w-3.5 h-3.5 text-purple-400" />
                Git Metadata & Fingerprint
              </h4>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Committed By:</span>
                <span className="text-slate-200 font-mono flex items-center gap-1">
                  <User className="w-3 h-3 text-slate-400" />
                  {finding.author}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>Commit Hash:</span>
                <span className="font-mono text-cyan-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                  {finding.commitHash}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
                <span className="flex items-center gap-1">
                  <Fingerprint className="w-3.5 h-3.5 text-slate-500" />
                  Hash Fingerprint:
                </span>
                <button
                  id="copy-fingerprint-btn"
                  onClick={handleCopyFingerprint}
                  className="font-mono text-[11px] text-slate-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  {finding.fingerprint.slice(0, 16)}...
                  <Copy className="w-3 h-3" />
                  {copiedFingerprint && <span className="text-emerald-400">Copied</span>}
                </button>
              </div>
            </div>
          </div>

          {/* Remediation Advice */}
          <div className="bg-slate-950/40 border border-slate-800 rounded-xl p-4">
            <h4 className="text-xs font-semibold text-amber-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5" />
              Recommended Security Remediation
            </h4>
            <p className="text-sm text-slate-300 leading-relaxed bg-amber-950/20 border border-amber-900/30 p-3 rounded-lg">
              {finding.remediationAdvice}
            </p>
          </div>

          {/* Audit Trail Log */}
          <div>
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              Audit Trail Log ({finding.auditLog.length})
            </h4>
            <div className="space-y-2 border-l-2 border-slate-800 pl-4 ml-1">
              {finding.auditLog.map((log, idx) => (
                <div key={idx} className="relative pb-2 text-xs">
                  <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-cyan-500 ring-4 ring-slate-900" />
                  <div className="flex items-center justify-between font-medium text-slate-200">
                    <span>{log.action}</span>
                    <span className="text-slate-500 font-mono text-[11px]">{log.timestamp}</span>
                  </div>
                  <div className="text-slate-400 text-[11px] mt-0.5">By: {log.user}</div>
                  {log.notes && (
                    <div className="mt-1 text-slate-300 bg-slate-950/60 border border-slate-800/80 p-2 rounded text-[11px]">
                      {log.notes}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Status Change Controls */}
          <div className="pt-4 border-t border-slate-800">
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3">
              Change Finding Status
            </h4>

            {!canResolveFindings && (
              <div className="text-xs text-amber-300/90 bg-amber-950/30 border border-amber-800/40 p-2.5 rounded-lg mb-3">
                Viewing role permissions: You are currently signed in as a Viewer. Switch role to Security Analyst, Admin, or Owner in the header to modify finding status.
              </div>
            )}

            <div className="mb-3">
              <input
                id="finding-status-notes-input"
                type="text"
                placeholder="Optional resolution notes (e.g., Rotated key in AWS Console)"
                value={statusNotes}
                onChange={(e) => setStatusNotes(e.target.value)}
                disabled={!canResolveFindings}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2 text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-cyan-500 disabled:opacity-50"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                id="action-mark-reviewing-btn"
                type="button"
                onClick={() => handleStatusChange('Reviewing')}
                disabled={!canResolveFindings || finding.status === 'Reviewing'}
                className="px-3 py-2 rounded-lg text-xs font-semibold bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 transition disabled:opacity-40"
              >
                Mark as Reviewing
              </button>

              <button
                id="action-mark-resolved-btn"
                type="button"
                onClick={() => handleStatusChange('Resolved')}
                disabled={!canResolveFindings || finding.status === 'Resolved'}
                className="px-3 py-2 rounded-lg text-xs font-semibold bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 transition disabled:opacity-40 flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                Mark as Resolved
              </button>

              <button
                id="action-mark-false-positive-btn"
                type="button"
                onClick={() => handleStatusChange('False Positive')}
                disabled={!canResolveFindings || finding.status === 'False Positive'}
                className="px-3 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition disabled:opacity-40"
              >
                Mark as False Positive
              </button>

              {finding.status !== 'Open' && (
                <button
                  id="action-reopen-finding-btn"
                  type="button"
                  onClick={() => handleStatusChange('Open')}
                  disabled={!canResolveFindings}
                  className="px-3 py-2 rounded-lg text-xs font-semibold bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 transition disabled:opacity-40 flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Reopen Finding
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-end">
          <button
            id="finding-modal-close-footer-btn"
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import {
  Activity,
  Award,
  Bell,
  FolderGit2,
  LayoutDashboard,
  LogOut,
  Menu,
  Settings,
  Shield,
  ShieldAlert,
  Terminal,
  Users,
  X,
} from 'lucide-react';
import { useData } from '../context/DataContext';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isOpen: boolean;
  onToggle: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPage,
  onNavigate,
  isOpen,
  onToggle,
}) => {
  const { findings, unreadNotificationsCount, logout } = useData();

  const openFindingsCount = findings.filter(
    (f) => f.status === 'Open' || f.status === 'Reviewing'
  ).length;

  const navigationItems = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'repositories',
      label: 'Repositories',
      icon: FolderGit2,
    },
    {
      id: 'scans',
      label: 'Scans',
      icon: Activity,
    },
    {
      id: 'findings',
      label: 'Findings',
      icon: ShieldAlert,
      badge: openFindingsCount > 0 ? openFindingsCount : undefined,
      badgeColor: 'bg-rose-500/20 text-rose-300 border border-rose-500/30',
    },
    {
      id: 'compliance',
      label: 'Compliance',
      icon: Award,
    },
    {
      id: 'team',
      label: 'Team',
      icon: Users,
    },
    {
      id: 'developer-tools',
      label: 'Developer Tools',
      icon: Terminal,
    },
    {
      id: 'notifications',
      label: 'Notifications',
      icon: Bell,
      badge: unreadNotificationsCount > 0 ? unreadNotificationsCount : undefined,
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30',
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: Settings,
    },
    {
      id: 'logout',
      label: 'Logout',
      icon: LogOut,
      isAction: true,
    },
  ];

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          id="sidebar-backdrop"
          onClick={onToggle}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-xs lg:hidden"
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed top-0 bottom-0 left-0 z-40 w-64 bg-slate-950 border-r border-slate-800 flex flex-col transition-transform duration-200 ease-in-out lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 px-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-linear-to-tr from-cyan-600 to-emerald-500 flex items-center justify-center shadow-lg shadow-cyan-900/30 text-slate-950">
              <Shield className="w-5 h-5 font-bold" />
            </div>
            <div>
              <span className="font-bold text-sm tracking-tight text-slate-100 flex items-center gap-1">
                Secret Leak <span className="text-cyan-400">Detector</span>
              </span>
              <span className="block text-[10px] text-slate-400 font-mono tracking-wider uppercase">
                Enterprise Guard
              </span>
            </div>
          </div>

          <button
            id="sidebar-close-mobile-btn"
            onClick={onToggle}
            className="lg:hidden p-1 text-slate-400 hover:text-slate-200 rounded-md hover:bg-slate-900"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            const isLogout = item.id === 'logout';

            return (
              <button
                key={item.id}
                id={`sidebar-nav-${item.id}`}
                onClick={() => {
                  if (isLogout) {
                    if (window.innerWidth < 1024) {
                      onToggle();
                    }
                    logout();
                    return;
                  }
                  onNavigate(item.id);
                  if (window.innerWidth < 1024) {
                    onToggle();
                  }
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                  isLogout
                    ? 'text-rose-400/80 hover:text-rose-300 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20'
                    : isActive
                    ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/80 border border-transparent'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon
                    className={`w-4 h-4 transition-colors ${
                      isLogout
                        ? 'text-rose-400/80 group-hover:text-rose-300'
                        : isActive
                        ? 'text-cyan-400'
                        : 'text-slate-400 group-hover:text-slate-200'
                    }`}
                  />
                  <span>{item.label}</span>
                </div>

                {item.badge !== undefined && (
                  <span
                    id={`nav-badge-${item.id}`}
                    className={`px-2 py-0.5 text-[10px] font-bold rounded-full font-mono ${item.badgeColor}`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Footer info */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60">
          <div className="bg-slate-900/80 border border-slate-800 rounded-lg p-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-[11px] font-medium text-slate-300">Protection Status</span>
              <span className="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                Active
              </span>
            </div>
            <p className="text-[10px] text-slate-400 leading-tight">
              Zero-Trust Masking Active: Raw keys are never stored.
            </p>
          </div>
        </div>
      </aside>
    </>
  );
};

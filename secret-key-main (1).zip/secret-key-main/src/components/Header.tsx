import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  ChevronDown,
  LogOut,
  Menu,
  RotateCcw,
  Settings as SettingsIcon,
  Shield,
  ShieldCheck,
  User,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { TeamRole } from '../types';

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onToggleMobileSidebar?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  onToggleMobileSidebar,
}) => {
  const {
    currentUser,
    switchUserRole,
    complianceMetrics,
    unreadNotificationsCount,
    resetToDemoData,
    logout,
  } = useData();

  const [isRoleMenuOpen, setIsRoleMenuOpen] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const rolesList: TeamRole[] = ['Owner', 'Admin', 'Security Analyst', 'Developer', 'Viewer'];

  // Display user's first name, e.g. "Ranjith"
  const firstName = currentUser.name ? currentUser.name.split(' ')[0] : 'User';

  const getPageTitle = () => {
    switch (currentPage) {
      case 'dashboard':
        return 'Security Overview';
      case 'repositories':
        return 'Monitored Repositories';
      case 'scans':
        return 'Scan History & Triggers';
      case 'findings':
        return 'Detected Secret Findings';
      case 'compliance':
        return 'Security & Compliance Audits';
      case 'team':
        return 'Team Access & Permissions';
      case 'developer-tools':
        return 'Developer Pre-Commit Hook & Demo Scanner';
      case 'notifications':
        return 'Security Alerts & Notifications';
      case 'settings':
        return 'Scanner & System Settings';
      default:
        return 'Secret Leak Detector';
    }
  };

  return (
    <header
      id="app-header"
      className="h-16 border-b border-slate-800 bg-slate-900/80 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between sticky top-0 z-30"
    >
      {/* Left: Mobile Toggle + Page Title & Welcome */}
      <div className="flex items-center gap-3">
        {onToggleMobileSidebar && (
          <button
            id="header-mobile-sidebar-btn"
            type="button"
            onClick={onToggleMobileSidebar}
            className="lg:hidden p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 rounded-lg transition"
            title="Open Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
        )}

        <div>
          <h1 className="text-sm sm:text-base font-bold text-slate-100 flex items-center gap-2">
            {getPageTitle()}
          </h1>
          <p id="header-user-welcome" className="text-[11px] text-slate-400 hidden sm:block">
            Welcome, <span className="font-semibold text-cyan-400">{firstName}</span>
          </p>
        </div>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-2 sm:gap-4">
        {/* Mobile Welcome Tag */}
        <span className="sm:hidden text-xs text-slate-300 font-medium">
          Hi, <span className="text-cyan-400 font-semibold">{firstName}</span>
        </span>

        {/* Compliance Score Pill */}
        <button
          id="header-compliance-pill"
          type="button"
          onClick={() => onNavigate('compliance')}
          className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded-full bg-cyan-950/40 border border-cyan-800/50 text-cyan-300 text-xs font-semibold hover:bg-cyan-900/40 transition"
          title="Click to view full Compliance details"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          <span>Score: {complianceMetrics.score}%</span>
          <span
            className={`text-[10px] font-mono ${
              complianceMetrics.change >= 0 ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {complianceMetrics.change >= 0 ? `+${complianceMetrics.change}` : complianceMetrics.change}
          </span>
        </button>

        {/* Reset Demo Data quick button */}
        <button
          id="header-reset-demo-btn"
          type="button"
          onClick={() => setShowResetConfirm(true)}
          className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-slate-800 text-xs hidden xl:flex items-center gap-1 transition"
          title="Reset database to initial demo state"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span className="text-[11px]">Reset Data</span>
        </button>

        {/* Notification Bell with Badge */}
        <button
          id="header-notification-btn"
          type="button"
          onClick={() => onNavigate('notifications')}
          className="relative p-2 text-slate-300 hover:text-slate-100 hover:bg-slate-800 rounded-lg transition"
          title="View Notifications"
        >
          <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
          {unreadNotificationsCount > 0 && (
            <span
              id="header-notification-badge"
              className="absolute top-1 right-1 min-w-[18px] h-[18px] px-1 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse"
            >
              {unreadNotificationsCount}
            </span>
          )}
        </button>

        {/* User Profile & Role Switcher */}
        <div className="relative">
          <button
            id="user-role-selector-btn"
            type="button"
            onClick={() => setIsRoleMenuOpen(!isRoleMenuOpen)}
            className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 text-xs font-medium text-slate-200 transition"
          >
            <div className="w-6 h-6 rounded-full bg-cyan-600/30 border border-cyan-500/40 text-cyan-300 flex items-center justify-center font-bold text-xs">
              {currentUser.name.charAt(0)}
            </div>
            <div className="text-left hidden sm:block leading-tight">
              <div className="font-semibold text-slate-100 text-xs truncate max-w-[120px]">
                {currentUser.name}
              </div>
              <div className="text-[10px] text-cyan-400 font-mono font-medium">
                {currentUser.role}
              </div>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
          </button>

          {/* User Dropdown */}
          {isRoleMenuOpen && (
            <div
              id="user-role-dropdown"
              className="absolute right-0 mt-2 w-60 bg-slate-900 border border-slate-800 rounded-xl shadow-xl py-2 z-50 animate-in fade-in zoom-in-95 duration-100"
            >
              <div className="px-3 py-2 border-b border-slate-800 mb-1">
                <p className="text-[11px] text-slate-400">Signed in as</p>
                <p className="text-xs font-bold text-slate-100 truncate">{currentUser.name}</p>
                <p className="text-[11px] text-slate-400 truncate font-mono">{currentUser.email}</p>
              </div>

              {/* Quick Settings Link */}
              <div className="px-2 py-1">
                <button
                  id="dropdown-settings-link"
                  type="button"
                  onClick={() => {
                    onNavigate('settings');
                    setIsRoleMenuOpen(false);
                  }}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 text-slate-300 hover:bg-slate-800 transition"
                >
                  <SettingsIcon className="w-3.5 h-3.5 text-slate-400" />
                  <span>Account & Profile Settings</span>
                </button>
              </div>

              {/* RBAC Role Switcher */}
              <div className="px-2 py-1 border-t border-slate-800/80 mt-1">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1">
                  Switch Role (Test RBAC)
                </p>
                {rolesList.map((role) => (
                  <button
                    key={role}
                    id={`role-switch-${role.toLowerCase().replace(/\s+/g, '-')}`}
                    onClick={() => {
                      switchUserRole(role);
                      setIsRoleMenuOpen(false);
                    }}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center justify-between transition ${
                      currentUser.role === role
                        ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                        : 'text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    <span>{role}</span>
                    {currentUser.role === role && <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />}
                  </button>
                ))}
              </div>

              {/* Logout Action */}
              <div className="px-2 pt-1 border-t border-slate-800/80 mt-1">
                <button
                  id="dropdown-logout-btn"
                  type="button"
                  onClick={() => {
                    setIsRoleMenuOpen(false);
                    logout();
                  }}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 text-rose-400 hover:bg-rose-500/10 hover:text-rose-300 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Confirmation for Demo Data Reset */}
      {showResetConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-sm w-full text-slate-100">
            <h3 className="text-base font-bold text-slate-100 mb-2">Reset to Demo State?</h3>
            <p className="text-xs text-slate-400 mb-5">
              This will restore all repositories, scans, findings, team members, and settings to their clean demo defaults.
            </p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowResetConfirm(false)}
                className="px-3 py-1.5 rounded-lg text-xs bg-slate-800 text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  resetToDemoData();
                  setShowResetConfirm(false);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 text-white hover:bg-rose-700"
              >
                Yes, Reset Data
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};


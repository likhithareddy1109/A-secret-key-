import { DetectionMethod, RiskLevel } from '../types';

export interface ScanMatch {
  secretType: string;
  maskedValue: string;
  fingerprint: string;
  lineNumber: number;
  columnNumber: number;
  riskLevel: RiskLevel;
  confidence: number;
  detectionMethod: DetectionMethod;
  lineSnippet: string;
  explanation: string;
}

// Shannon Entropy formula: H = -sum(p * log2(p))
export function calculateShannonEntropy(str: string): number {
  if (!str || str.length === 0) return 0;
  const frequencies = new Map<string, number>();
  for (const char of str) {
    frequencies.set(char, (frequencies.get(char) || 0) + 1);
  }

  let entropy = 0;
  const len = str.length;
  for (const count of frequencies.values()) {
    const p = count / len;
    entropy -= p * Math.log2(p);
  }
  return Number(entropy.toFixed(2));
}

// Strictly masks any secret so raw secrets are never displayed or stored
export function maskSecret(value: string): string {
  if (!value) return '********';
  const clean = value.trim();
  const len = clean.length;
  if (len <= 6) {
    return '******';
  }
  if (len <= 12) {
    return clean.slice(0, 2) + '*'.repeat(len - 4) + clean.slice(-2);
  }
  const prefixLen = Math.min(4, Math.floor(len * 0.2));
  const suffixLen = Math.min(4, Math.floor(len * 0.2));
  const maskedCount = Math.max(6, len - prefixLen - suffixLen);
  return clean.slice(0, prefixLen) + '*'.repeat(maskedCount) + clean.slice(-suffixLen);
}

// Generate deterministic pseudo-SHA256 fingerprint for identity comparison without plaintext
export function generateFingerprint(value: string): string {
  let hash1 = 0x811c9dc5;
  let hash2 = 0x5bd1e995;
  for (let i = 0; i < value.length; i++) {
    const code = value.charCodeAt(i);
    hash1 ^= code;
    hash1 = (hash1 * 0x01000193) >>> 0;
    hash2 ^= (code << 5) + code;
    hash2 = (hash2 * 0x27d4eb2d) >>> 0;
  }
  const part1 = hash1.toString(16).padStart(8, '0');
  const part2 = hash2.toString(16).padStart(8, '0');
  return `sec_fp_${part1}${part2}99a4c8`;
}

interface SecretPatternRule {
  type: string;
  regex: RegExp;
  risk: RiskLevel;
  confidence: number;
  explanation: string;
  method: DetectionMethod;
}

const SECRET_PATTERNS: SecretPatternRule[] = [
  {
    type: 'AWS Access Key ID',
    regex: /\b(AKIA|ABIA|ACCA|ASIA)[0-9A-Z]{16}\b/g,
    risk: 'Critical',
    confidence: 99,
    explanation: 'Standard AWS IAM access key ID format.',
    method: 'Regex Rule',
  },
  {
    type: 'GitHub Personal Access Token',
    regex: /\b(ghp_[0-9a-zA-Z]{36}|github_pat_[0-9a-zA-Z_]{22,60})\b/g,
    risk: 'Critical',
    confidence: 98,
    explanation: 'GitHub Personal Access Token signature detected.',
    method: 'Regex Rule',
  },
  {
    type: 'Slack Bot / User Token',
    regex: /\bxox[baprs]-[0-9a-zA-Z]{10,48}\b/g,
    risk: 'High',
    confidence: 95,
    explanation: 'Slack API authorization token format detected.',
    method: 'Regex Rule',
  },
  {
    type: 'Slack Webhook URL',
    regex: /https:\/\/hooks\.slack\.com\/services\/T[0-9A-Z]{8,12}\/B[0-9A-Z]{8,12}\/[0-9A-Za-z]{24}/g,
    risk: 'High',
    confidence: 97,
    explanation: 'Slack incoming webhook endpoint with embedded credentials.',
    method: 'Regex Rule',
  },
  {
    type: 'Private RSA/EC Encryption Key',
    regex: /-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----/g,
    risk: 'Critical',
    confidence: 99,
    explanation: 'Cryptographic private key file block detected.',
    method: 'Regex Rule',
  },
  {
    type: 'JSON Web Token (JWT)',
    regex: /\beyJ[A-Za-z0-9-_]{10,}\.[A-Za-z0-9-_]{10,}\.[A-Za-z0-9-_]{10,}\b/g,
    risk: 'Medium',
    confidence: 88,
    explanation: 'Signed JWT token containing potentially sensitive claims/signatures.',
    method: 'Pattern Matching' as DetectionMethod,
  },
  {
    type: 'Database Connection String',
    regex: /\b(?:postgres|postgresql|mysql|mongodb|redis):\/\/[a-zA-Z0-9_-]+:[^@\s]+@[a-zA-Z0-9.-]+(?::[0-9]+)?\/[a-zA-Z0-9_-]+/g,
    risk: 'Critical',
    confidence: 96,
    explanation: 'Database URI containing embedded plaintext username and password credentials.',
    method: 'Regex Rule',
  },
  {
    type: 'Stripe Live Secret Key',
    regex: /\bsk_live_[0-9a-zA-Z]{24,32}\b/g,
    risk: 'Critical',
    confidence: 99,
    explanation: 'Stripe live production secret key detected.',
    method: 'Regex Rule',
  },
  {
    type: 'Generic API Key / Secret Assignment',
    regex: /(?:api_?key|secret|auth_?token|client_?secret|access_?token)\s*[:=]\s*["']([A-Za-z0-9+/=_\-.]{16,})["']/gi,
    risk: 'High',
    confidence: 85,
    explanation: 'Variable assignment matching credential naming conventions.',
    method: 'Entropy + Pattern',
  },
  {
    type: 'Demo / Test Key Pattern',
    regex: /\b(DEMO_FAKE_KEY_[0-9A-Za-z_]+|YOUR_API_KEY_HERE|EXAMPLE_TOKEN|CHANGE_ME)\b/g,
    risk: 'Low',
    confidence: 92,
    explanation: 'Known placeholder or demo credential string.',
    method: 'Regex Rule',
  },
];

export function scanCodeForSecrets(
  content: string,
  options: {
    entropyEnabled?: boolean;
    confidenceThreshold?: number;
    ignoreTestDemo?: boolean;
  } = {}
): ScanMatch[] {
  const { entropyEnabled = true, confidenceThreshold = 70, ignoreTestDemo = false } = options;
  const matches: ScanMatch[] = [];
  const lines = content.split('\n');

  // Track discovered positions to prevent duplicate entries
  const seenFindings = new Set<string>();

  for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
    const line = lines[lineIdx];
    const lineNumber = lineIdx + 1;

    for (const rule of SECRET_PATTERNS) {
      if (ignoreTestDemo && rule.type === 'Demo / Test Key Pattern') {
        continue;
      }

      // Reset regex index
      rule.regex.lastIndex = 0;
      let match: RegExpExecArray | null;

      while ((match = rule.regex.exec(line)) !== null) {
        const fullMatchedString = match[1] || match[0];
        const colNumber = match.index + 1;
        const key = `${lineNumber}:${colNumber}:${rule.type}`;

        if (!seenFindings.has(key)) {
          seenFindings.add(key);

          // Calculate entropy if enabled
          let finalConfidence = rule.confidence;
          let method = rule.method;

          if (entropyEnabled && fullMatchedString.length >= 16) {
            const entropy = calculateShannonEntropy(fullMatchedString);
            if (entropy > 4.2) {
              finalConfidence = Math.min(100, rule.confidence + 5);
              method = 'Entropy + Pattern';
            }
          }

          if (finalConfidence >= confidenceThreshold) {
            matches.push({
              secretType: rule.type,
              maskedValue: maskSecret(fullMatchedString),
              fingerprint: generateFingerprint(fullMatchedString),
              lineNumber,
              columnNumber: colNumber,
              riskLevel: rule.risk,
              confidence: finalConfidence,
              detectionMethod: method,
              lineSnippet: line.trim(),
              explanation: rule.explanation,
            });
          }
        }
      }
    }

    // Secondary high-entropy standalone string check if entropyEnabled
    if (entropyEnabled) {
      const tokens = line.split(/[\s"',;=()\[\]{}]+/);
      for (const token of tokens) {
        if (token.length >= 24 && !token.includes('/') && !token.includes('http')) {
          const entropy = calculateShannonEntropy(token);
          if (entropy >= 4.35) {
            const colNumber = Math.max(1, line.indexOf(token) + 1);
            const key = `${lineNumber}:${colNumber}:ShannonEntropy`;
            if (!seenFindings.has(key)) {
              seenFindings.add(key);
              matches.push({
                secretType: 'High-Entropy Random String',
                maskedValue: maskSecret(token),
                fingerprint: generateFingerprint(token),
                lineNumber,
                columnNumber: colNumber,
                riskLevel: 'Medium',
                confidence: 84,
                detectionMethod: 'Shannon Entropy Analysis',
                lineSnippet: line.trim(),
                explanation: `High Shannon entropy (${entropy} bits/char) indicates a pseudorandom secret, cryptographic salt, or API key.`,
              });
            }
          }
        }
      }
    }
  }

  return matches;
}

export const PRECOMMIT_HOOK_SCRIPT = `#!/usr/bin/env bash
# ==============================================================================
# Secret Leak Detector - Git Pre-Commit Hook
# Place this script in your local repository at: .git/hooks/pre-commit
# Ensure it is executable: chmod +x .git/hooks/pre-commit
#
# NOTE: This hook runs locally on your machine during 'git commit'.
# The Secret Leak Detector web application does NOT install anything automatically.
# ==============================================================================

set -e

RED='\\033[0;31m'
GREEN='\\033[0;32m'
YELLOW='\\033[1;33m'
CYAN='\\033[0;36m'
NC='\\033[0m' # No Color

echo -e "\${CYAN}[Secret Leak Detector]\${NC} Analyzing staged files before commit..."

# Get staged files (excluding deletions)
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM)

if [ -z "$STAGED_FILES" ]; then
    echo -e "\${GREEN}[Secret Leak Detector]\${NC} No staged files to scan. Proceeding."
    exit 0
fi

SECRETS_FOUND=0

# High-risk secret patterns to block
PATTERNS=(
    "AKIA[0-9A-Z]{16}"                          # AWS Access Key
    "ghp_[0-9a-zA-Z]{36}"                       # GitHub PAT
    "xox[baprs]-[0-9a-zA-Z]{10,48}"             # Slack Token
    "-----BEGIN (RSA|EC|OPENSSH) PRIVATE KEY---" # Private Keys
    "sk_live_[0-9a-zA-Z]{24}"                   # Stripe Secret Key
    "(postgres|mysql|mongodb)://[^:]+:[^@]+@"   # DB connection URIs
)

for FILE in $STAGED_FILES; do
    # Skip binary files, lockfiles, and git directory
    if git check-attr -a "$FILE" | grep -q "binary: set"; then
        continue
    fi

    for PATTERN in "\${PATTERNS[@]}"; do
        MATCHES=$(git diff --cached "$FILE" | grep -E "^\\+" | grep -v "^\\+\\+\\+" | grep -E "$PATTERN" || true)
        if [ -n "$MATCHES" ]; then
            echo -e "\${RED}[CRITICAL LEAK BLOCKED]\${NC} Detected high-risk credential in: \${YELLOW}$FILE\${NC}"
            echo -e "Pattern signature: $PATTERN"
            SECRETS_FOUND=$((SECRETS_FOUND + 1))
        fi
    done
done

if [ "$SECRETS_FOUND" -gt 0 ]; then
    echo ""
    echo -e "\${RED}====================================================================\${NC}"
    echo -e "\${RED}COMMIT BLOCKED:\${NC} Secret Leak Detector stopped $SECRETS_FOUND potential secret leak(s)."
    echo -e "Remove credentials, mask values, or utilize safe environment variables."
    echo -e "To bypass temporarily (EMERGENCY ONLY): git commit --no-verify"
    echo -e "\${RED}====================================================================\${NC}"
    exit 1
fi

echo -e "\${GREEN}[Secret Leak Detector]\${NC} All staged files passed security inspection. Commit allowed!"
exit 0
`;

export const SAFE_DEMO_CODE_SNIPPET = `// Safe demo code for Secret Leak Detector testing
// All values below are purely synthetic dummy examples.

import { initClient } from '@demo/gateway';

// Demo configuration file (Simulated Leak)
export const config = {
  appName: 'payment-microservice-demo',
  environment: 'production-demo',
  
  // High-Risk Credential Simulation (Regex Rule)
  awsAccessKeyId: 'AKIAIOSFODNN7EXAMPLE',
  
  // Safe Synthetic Token (Regex Pattern)
  slackNotificationWebhook: 'https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX',
  
  // Safe Demo Key Marker
  sandboxKey: 'DEMO_FAKE_KEY_123456',
  
  // Generic High-Entropy Secret Key Assignment
  jwtSecretHash: 'a8f9c2d7e1b4029f6381bc59e74d12aa901c3e4b7829fae1',
  
  // Safe placeholder credentials
  fallbackApiKey: 'YOUR_API_KEY_HERE',
  tempPassword: 'CHANGE_ME'
};

export function connectDatabase() {
  // Simulated PostgreSQL URI with embedded credentials
  const connectionString = 'postgres://admin_demo:db_password_xyz987@db.internal.infra.net:5432/core_demo';
  return initClient({ connectionString });
}
`;

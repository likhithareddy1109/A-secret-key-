import { AuthUserAccount } from '../types';

const SALT = 'sld_enterprise_salt_2026';
const USERS_STORAGE_KEY = 'secret_leak_detector_accounts_v2';
const SESSION_STORAGE_KEY = 'secret_leak_detector_active_session_v2';

/**
 * Hash password with SHA-256 and salt using Web Crypto API.
 * Passwords are NEVER stored in plain text.
 */
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password + SALT);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Pre-seeded default demo user: "Ranjith Kumar"
export const DEFAULT_DEMO_ACCOUNTS: AuthUserAccount[] = [
  {
    id: 'user-ranjith-lead',
    name: 'Ranjith Kumar',
    email: 'ranjith@enterprise.io',
    // Pre-computed SHA-256 hash of 'Password123!' + SALT
    passwordHash: '84b7a13c9fb605cbdfaef69bc87258a4c8cf66a2e8eaeeebafbcebfa658e376a',
    role: 'Owner',
    createdAt: '2026-08-15',
    authProvider: 'local',
  },
  {
    id: 'user-alex-chen',
    name: 'Alex Chen',
    email: 'alex.chen@enterprise.io',
    passwordHash: '84b7a13c9fb605cbdfaef69bc87258a4c8cf66a2e8eaeeebafbcebfa658e376a',
    role: 'Security Analyst',
    createdAt: '2026-08-18',
    authProvider: 'local',
  },
];

export function getStoredAccounts(): AuthUserAccount[] {
  try {
    const raw = localStorage.getItem(USERS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(DEFAULT_DEMO_ACCOUNTS));
      return DEFAULT_DEMO_ACCOUNTS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : DEFAULT_DEMO_ACCOUNTS;
  } catch {
    return DEFAULT_DEMO_ACCOUNTS;
  }
}

export function saveStoredAccounts(accounts: AuthUserAccount[]): void {
  try {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(accounts));
  } catch {
    // ignore quota
  }
}

export function getSavedSession(): { user: AuthUserAccount; timestamp: number } | null {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    // Valid session structure
    if (parsed && parsed.user && parsed.user.email) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

export function saveSession(user: AuthUserAccount): void {
  try {
    localStorage.setItem(
      SESSION_STORAGE_KEY,
      JSON.stringify({
        user,
        timestamp: Date.now(),
      })
    );
  } catch {
    // ignore
  }
}

export function clearSession(): void {
  try {
    localStorage.removeItem(SESSION_STORAGE_KEY);
  } catch {
    // ignore
  }
}

export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export function validatePassword(password: string): { valid: boolean; message?: string } {
  if (!password) {
    return { valid: false, message: 'Password is required' };
  }
  if (password.length < 8) {
    return { valid: false, message: 'Password must be at least 8 characters long' };
  }
  return { valid: true };
}

export type RiskLevel = 'Critical' | 'High' | 'Medium' | 'Low';

export type FindingStatus = 'Open' | 'Reviewing' | 'Resolved' | 'False Positive';

export type DetectionMethod = 'Entropy + Pattern' | 'Regex Rule' | 'Shannon Entropy Analysis' | 'Heuristic Check';

export interface SecretFinding {
  id: string;
  repoId: string;
  repoName: string;
  secretType: string;
  fileName: string;
  lineNumber: number;
  riskLevel: RiskLevel;
  confidence: number; // 0 to 100 percentage
  detectionMethod: DetectionMethod;
  status: FindingStatus;
  detectedDate: string; // ISO string or format YYYY-MM-DD
  maskedPreview: string; // NEVER raw secret! e.g., DEMO_FAK********3456
  fingerprint: string; // SHA-256 fingerprint hash for lookup
  author: string;
  commitHash: string;
  remediationAdvice: string;
  auditLog: {
    action: string;
    user: string;
    timestamp: string;
    notes?: string;
  }[];
}

export interface Repository {
  id: string;
  name: string;
  url: string;
  defaultBranch: string;
  language: string;
  visibility?: 'Private' | 'Public';
  autoScan: boolean;
  totalScans: number;
  openFindings: number;
  criticalCount: number;
  highCount: number;
  healthScore: number;
  lastScanDate: string;
  createdAt: string;
}

export interface ScanRecord {
  id: string;
  repoId: string;
  repoName: string;
  triggerType: 'Pre-commit hook' | 'CI/CD pipeline' | 'Scheduled scan' | 'Manual trigger';
  status: 'Completed' | 'Failed' | 'Running';
  findingsDetected: number;
  filesScanned: number;
  durationSeconds: number;
  scannedAt: string;
  commitHash: string;
  scannedBy: string;
}

export type TeamRole = 'Owner' | 'Admin' | 'Security Analyst' | 'Developer' | 'Viewer';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: TeamRole;
  status: 'Active' | 'Invited' | 'Suspended';
  joinedDate: string;
  lastActive: string;
  avatarUrl?: string;
}

export interface AuthUserAccount {
  id: string;
  name: string;
  email: string;
  passwordHash: string; // SHA-256 salted hash, NEVER plain text
  role: TeamRole;
  createdAt: string;
  authProvider: 'local' | 'google';
  avatarUrl?: string;
}

export type NotificationType =
  | 'finding_critical'
  | 'finding_high'
  | 'scan_completed'
  | 'scan_failed'
  | 'finding_resolved'
  | 'repo_added'
  | 'team_member_added'
  | 'compliance_changed';

export type NotificationSeverity = 'critical' | 'high' | 'warning' | 'info' | 'success';

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: NotificationType;
  severity: NotificationSeverity;
  timestamp: string;
  read: boolean;
  targetId?: string;
}

export interface UserSettings {
  profile: {
    name: string;
    email: string;
    avatar: string;
    title: string;
  };
  security: {
    twoFactorEnabled: boolean;
    sessionTimeoutMinutes: number;
    lastPasswordChange: string;
    enforceStrongPasswords: boolean;
  };
  scanner: {
    entropyDetection: boolean;
    confidenceThreshold: number; // e.g. 80
    defaultScanBehavior: 'deep' | 'incremental' | 'fast';
    fileExclusions: string;
    ignoreTestFiles: boolean;
  };
  notifications: {
    criticalAlerts: boolean;
    highRiskAlerts: boolean;
    scanCompletionAlerts: boolean;
    complianceAlerts: boolean;
    teamActivityAlerts: boolean;
  };
  repository: {
    defaultBranch: string;
    automaticScanPreference: 'push' | 'nightly' | 'manual';
    scanFrequency: 'continuous' | 'daily' | 'weekly';
  };
  appearance: {
    theme: 'dark' | 'light';
    layout: 'comfortable' | 'compact';
  };
}

export interface ComplianceMetrics {
  score: number;
  previousScore: number;
  change: number; // e.g. +3 or -2
  trend: 'improving' | 'declining' | 'stable';
  totalRepositories: number;
  totalScans: number;
  cleanScans: number;
  failedScans: number;
  secretsDetected: number;
  criticalFindings: number;
  highFindings: number;
  resolvedFindings: number;
  openFindings: number;
  scanCoveragePercent: number;
  lastCalculatedDate: string;
}

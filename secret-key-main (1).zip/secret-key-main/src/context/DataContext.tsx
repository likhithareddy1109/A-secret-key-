import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  clearSession,
  getSavedSession,
  getStoredAccounts,
  hashPassword,
  saveSession,
  saveStoredAccounts,
  validateEmail,
  validatePassword,
} from '../services/authService';
import {
  INITIAL_FINDINGS,
  INITIAL_NOTIFICATIONS,
  INITIAL_REPOSITORIES,
  INITIAL_SCANS,
  INITIAL_TEAM_MEMBERS,
  INITIAL_USER_SETTINGS,
} from '../services/mockData';
import {
  AuthUserAccount,
  ComplianceMetrics,
  FindingStatus,
  NotificationItem,
  Repository,
  RiskLevel,
  ScanRecord,
  SecretFinding,
  TeamMember,
  UserSettings,
} from '../types';

interface DataContextType {
  findings: SecretFinding[];
  repositories: Repository[];
  scans: ScanRecord[];
  teamMembers: TeamMember[];
  notifications: NotificationItem[];
  settings: UserSettings;
  currentUser: TeamMember;
  complianceMetrics: ComplianceMetrics;
  unreadNotificationsCount: number;

  // Authentication State & Actions
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  loginWithGoogle: (googleUser?: { name: string; email: string; avatar?: string }) => Promise<{ success: boolean }>;
  logout: () => void;
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>;

  // Actions for Findings
  updateFindingStatus: (id: string, newStatus: FindingStatus, notes?: string) => void;
  createFinding: (finding: Omit<SecretFinding, 'id' | 'auditLog'>) => SecretFinding;

  // Actions for Repositories & Scans
  addRepository: (repo: Omit<Repository, 'id' | 'totalScans' | 'openFindings' | 'criticalCount' | 'highCount' | 'healthScore' | 'lastScanDate' | 'createdAt'>) => Repository;
  deleteRepository: (id: string) => void;
  triggerScan: (repoId: string, triggerType?: ScanRecord['triggerType']) => Promise<ScanRecord>;

  // Actions for Team
  addTeamMember: (member: Omit<TeamMember, 'id' | 'joinedDate' | 'lastActive'>) => TeamMember;
  updateTeamMember: (id: string, updates: Partial<TeamMember>) => void;
  removeTeamMember: (id: string) => void;

  // Actions for Notifications
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  deleteNotification: (id: string) => void;
  clearAllNotifications: () => void;

  // Actions for Settings & User
  updateSettings: (newSettings: Partial<UserSettings>) => void;
  setCurrentUser: (member: TeamMember) => void;
  switchUserRole: (role: TeamMember['role']) => void;
  resetToDemoData: () => void;

  // Authorization flags
  canManageTeam: boolean;
  canManageSettings: boolean;
  canResolveFindings: boolean;
  canTriggerScan: boolean;
}

const STORAGE_KEY = 'secret_leak_detector_state_v2';

const DataContext = createContext<DataContextType | undefined>(undefined);

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Load state from localStorage or initialize with mock data
  const [findings, setFindings] = useState<SecretFinding[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_findings`);
      return saved ? JSON.parse(saved) : INITIAL_FINDINGS;
    } catch {
      return INITIAL_FINDINGS;
    }
  });

  const [repositories, setRepositories] = useState<Repository[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_repos`);
      return saved ? JSON.parse(saved) : INITIAL_REPOSITORIES;
    } catch {
      return INITIAL_REPOSITORIES;
    }
  });

  const [scans, setScans] = useState<ScanRecord[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_scans`);
      return saved ? JSON.parse(saved) : INITIAL_SCANS;
    } catch {
      return INITIAL_SCANS;
    }
  });

  const [teamMembers, setTeamMembers] = useState<TeamMember[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_team`);
      return saved ? JSON.parse(saved) : INITIAL_TEAM_MEMBERS;
    } catch {
      return INITIAL_TEAM_MEMBERS;
    }
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_notifications`);
      return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  });

  const [settings, setSettings] = useState<UserSettings>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_settings`);
      return saved ? JSON.parse(saved) : INITIAL_USER_SETTINGS;
    } catch {
      return INITIAL_USER_SETTINGS;
    }
  });

  // Session Authentication: Defaults to false so Login/Welcome page appears FIRST
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      const isSessionActive = sessionStorage.getItem('sld_authenticated');
      if (isSessionActive === 'true') {
        const savedSession = getSavedSession();
        return !!savedSession;
      }
      return false; // Default: unauthenticated to show Welcome / Login screen first!
    } catch {
      return false;
    }
  });

  const [currentUser, setCurrentUser] = useState<TeamMember>(() => {
    try {
      const savedSession = getSavedSession();
      if (savedSession && savedSession.user) {
        const matched = teamMembers.find((m) => m.email.toLowerCase() === savedSession.user.email.toLowerCase());
        if (matched) return matched;
        return {
          id: savedSession.user.id,
          name: savedSession.user.name,
          email: savedSession.user.email,
          role: savedSession.user.role,
          status: 'Active',
          joinedDate: savedSession.user.createdAt,
          lastActive: 'Just now',
          avatarUrl: savedSession.user.avatarUrl,
        };
      }
    } catch {
      // fallback
    }
    return teamMembers[0] || INITIAL_TEAM_MEMBERS[0];
  });

  // Track previous compliance score to show dynamic improvement/decline
  const [prevScoreRecord, setPrevScoreRecord] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(`${STORAGE_KEY}_prev_score`);
      return saved ? Number(saved) : 79;
    } catch {
      return 79;
    }
  });

  // Persist state to localStorage on changes
  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_findings`, JSON.stringify(findings));
    } catch { /* storage quota ignore */ }
  }, [findings]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_repos`, JSON.stringify(repositories));
    } catch { /* storage quota ignore */ }
  }, [repositories]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_scans`, JSON.stringify(scans));
    } catch { /* storage quota ignore */ }
  }, [scans]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_team`, JSON.stringify(teamMembers));
    } catch { /* storage quota ignore */ }
  }, [teamMembers]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_notifications`, JSON.stringify(notifications));
    } catch { /* storage quota ignore */ }
  }, [notifications]);

  useEffect(() => {
    try {
      localStorage.setItem(`${STORAGE_KEY}_settings`, JSON.stringify(settings));
    } catch { /* storage quota ignore */ }
  }, [settings]);

  // Apply theme to HTML root element
  useEffect(() => {
    const root = document.documentElement;
    if (settings.appearance.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.appearance.theme]);

  // Dynamic Compliance Calculation from actual application data
  const complianceMetrics: ComplianceMetrics = useMemo(() => {
    const totalRepos = repositories.length;
    const totalScans = scans.length;
    const cleanScans = scans.filter((s) => s.status === 'Completed' && s.findingsDetected === 0).length;
    const failedScans = scans.filter((s) => s.status === 'Failed' || s.findingsDetected > 0).length;
    const secretsDetected = findings.length;

    const openOrReviewing = findings.filter((f) => f.status === 'Open' || f.status === 'Reviewing');
    const criticalFindings = openOrReviewing.filter((f) => f.riskLevel === 'Critical').length;
    const highFindings = openOrReviewing.filter((f) => f.riskLevel === 'High').length;
    const mediumFindings = openOrReviewing.filter((f) => f.riskLevel === 'Medium').length;
    const lowFindings = openOrReviewing.filter((f) => f.riskLevel === 'Low').length;
    const resolvedFindings = findings.filter((f) => f.status === 'Resolved' || f.status === 'False Positive').length;
    const openFindings = openOrReviewing.length;

    // Scan coverage: % of repositories that have at least 1 scan
    const scannedRepoIds = new Set(scans.map((s) => s.repoId));
    const reposWithScans = repositories.filter((r) => scannedRepoIds.has(r.id)).length;
    const scanCoveragePercent = totalRepos > 0 ? Math.round((reposWithScans / totalRepos) * 100) : 0;

    // Dynamic formula: Base 100, penalize open risk findings
    let calculated = 100;
    calculated -= criticalFindings * 14;
    calculated -= highFindings * 7;
    calculated -= mediumFindings * 3;
    calculated -= lowFindings * 1;

    // Proportional adjustment for scan coverage and resolution rate
    if (scanCoveragePercent < 100) {
      calculated -= Math.round((100 - scanCoveragePercent) * 0.1);
    }
    if (findings.length > 0) {
      const resolutionRatio = resolvedFindings / findings.length;
      calculated += Math.round(resolutionRatio * 6);
    }

    // Clamp between 20 and 100
    const finalScore = Math.min(100, Math.max(20, calculated));
    const change = finalScore - prevScoreRecord;
    const trend: 'improving' | 'declining' | 'stable' =
      change > 0 ? 'improving' : change < 0 ? 'declining' : 'stable';

    const now = new Date();
    const lastCalculatedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    return {
      score: finalScore,
      previousScore: prevScoreRecord,
      change,
      trend,
      totalRepositories: totalRepos,
      totalScans,
      cleanScans,
      failedScans,
      secretsDetected,
      criticalFindings,
      highFindings,
      resolvedFindings,
      openFindings,
      scanCoveragePercent,
      lastCalculatedDate,
    };
  }, [repositories, scans, findings, prevScoreRecord]);

  // Recalculate repository health scores based on current findings
  useEffect(() => {
    setRepositories((prevRepos) => {
      let changed = false;
      const updated = prevRepos.map((repo) => {
        const repoFindings = findings.filter(
          (f) => f.repoId === repo.id && (f.status === 'Open' || f.status === 'Reviewing')
        );
        const criticalCount = repoFindings.filter((f) => f.riskLevel === 'Critical').length;
        const highCount = repoFindings.filter((f) => f.riskLevel === 'High').length;
        const openCount = repoFindings.length;
        const healthScore = Math.max(15, 100 - (criticalCount * 25 + highCount * 12 + (openCount - criticalCount - highCount) * 4));

        if (
          repo.openFindings !== openCount ||
          repo.criticalCount !== criticalCount ||
          repo.highCount !== highCount ||
          repo.healthScore !== healthScore
        ) {
          changed = true;
          return {
            ...repo,
            openFindings: openCount,
            criticalCount,
            highCount,
            healthScore,
          };
        }
        return repo;
      });
      return changed ? updated : prevRepos;
    });
  }, [findings]);

  // Helper to add internal notification
  const addInternalNotification = (notif: Omit<NotificationItem, 'id' | 'timestamp' | 'read'>) => {
    const now = new Date();
    const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newNotif: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp,
      read: false,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  // Status Change for Findings
  const updateFindingStatus = (id: string, newStatus: FindingStatus, notes?: string) => {
    const target = findings.find((f) => f.id === id);
    if (!target) return;

    const oldStatus = target.status;
    if (oldStatus === newStatus) return;

    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    setFindings((prev) =>
      prev.map((f) => {
        if (f.id === id) {
          return {
            ...f,
            status: newStatus,
            auditLog: [
              ...f.auditLog,
              {
                action: `Status changed from ${oldStatus} to ${newStatus}`,
                user: `${currentUser.name} (${currentUser.role})`,
                timestamp: timeStr,
                notes: notes || `Marked as ${newStatus} via Findings console.`,
              },
            ],
          };
        }
        return f;
      })
    );

    // If resolved, emit notification
    if (newStatus === 'Resolved') {
      addInternalNotification({
        title: 'Finding Resolved',
        message: `${target.secretType} in ${target.repoName} (${target.fileName}) marked as Resolved by ${currentUser.name}.`,
        type: 'finding_resolved',
        severity: 'success',
        targetId: id,
      });
    } else if (newStatus === 'False Positive') {
      addInternalNotification({
        title: 'Finding Marked False Positive',
        message: `${target.secretType} in ${target.repoName} marked as False Positive by ${currentUser.name}.`,
        type: 'finding_resolved',
        severity: 'info',
        targetId: id,
      });
    }
  };

  // Create new finding
  const createFinding = (findingData: Omit<SecretFinding, 'id' | 'auditLog'>): SecretFinding => {
    const newId = `SEC-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newFinding: SecretFinding = {
      ...findingData,
      id: newId,
      auditLog: [
        {
          action: 'Detected and registered in security database',
          user: `${currentUser.name} (${currentUser.role})`,
          timestamp: timeStr,
        },
      ],
    };

    setFindings((prev) => [newFinding, ...prev]);

    // Dispatch notification
    if (newFinding.riskLevel === 'Critical') {
      addInternalNotification({
        title: 'New Critical Finding Detected',
        message: `${newFinding.secretType} discovered in ${newFinding.repoName} (${newFinding.fileName}:${newFinding.lineNumber}). Immediate rotation required.`,
        type: 'finding_critical',
        severity: 'critical',
        targetId: newId,
      });
    } else if (newFinding.riskLevel === 'High') {
      addInternalNotification({
        title: 'New High Risk Finding Detected',
        message: `${newFinding.secretType} flagged in ${newFinding.repoName} (${newFinding.fileName}).`,
        type: 'finding_high',
        severity: 'high',
        targetId: newId,
      });
    }

    return newFinding;
  };

  // Add Repository
  const addRepository = (
    repoData: Omit<Repository, 'id' | 'totalScans' | 'openFindings' | 'criticalCount' | 'highCount' | 'healthScore' | 'lastScanDate' | 'createdAt'>
  ): Repository => {
    const newId = `repo-${Date.now()}`;
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    const timeStr = `${dateStr} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newRepo: Repository = {
      ...repoData,
      id: newId,
      totalScans: 0,
      openFindings: 0,
      criticalCount: 0,
      highCount: 0,
      healthScore: 100,
      lastScanDate: 'Never',
      createdAt: dateStr,
    };

    setRepositories((prev) => [newRepo, ...prev]);

    addInternalNotification({
      title: 'Repository Added',
      message: `Repository ${newRepo.name} has been enrolled for secret scanning.`,
      type: 'repo_added',
      severity: 'info',
    });

    return newRepo;
  };

  const deleteRepository = (id: string) => {
    const target = repositories.find((r) => r.id === id);
    setRepositories((prev) => prev.filter((r) => r.id !== id));
    setFindings((prev) => prev.filter((f) => f.repoId !== id));
    setScans((prev) => prev.filter((s) => s.repoId !== id));

    if (target) {
      addInternalNotification({
        title: 'Repository Removed',
        message: `Repository ${target.name} and associated findings were archived.`,
        type: 'repo_added',
        severity: 'warning',
      });
    }
  };

  // Trigger Scan on a repository
  const triggerScan = async (repoId: string, triggerType: ScanRecord['triggerType'] = 'Manual trigger'): Promise<ScanRecord> => {
    const repo = repositories.find((r) => r.id === repoId);
    if (!repo) throw new Error('Repository not found');

    const scanId = `SCAN-${Math.floor(800 + Math.random() * 200)}`;
    const now = new Date();
    const timeStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    // Simulate scan duration
    const filesScanned = Math.floor(80 + Math.random() * 180);
    const durationSeconds = Number((4 + Math.random() * 8).toFixed(1));

    // Determine if demo scan discovers a simulated leak or clean
    const willDiscoverSecret = Math.random() > 0.45;
    let findingsCount = 0;

    if (willDiscoverSecret) {
      findingsCount = 1;
      createFinding({
        repoId: repo.id,
        repoName: repo.name,
        secretType: 'Generic API Key / Secret Assignment',
        fileName: 'config/secrets.demo.json',
        lineNumber: Math.floor(10 + Math.random() * 40),
        riskLevel: 'High',
        confidence: 91,
        detectionMethod: 'Entropy + Pattern',
        status: 'Open',
        detectedDate: timeStr,
        maskedPreview: 'sec_live_********8f31',
        fingerprint: `sec_fp_${Math.random().toString(16).slice(2, 10)}99a4c8`,
        author: currentUser.email,
        commitHash: Math.random().toString(16).slice(2, 10),
        remediationAdvice: 'Rotate credential immediately and remove from version control tracking.',
      });
    }

    const newScan: ScanRecord = {
      id: scanId,
      repoId: repo.id,
      repoName: repo.name,
      triggerType,
      status: 'Completed',
      findingsDetected: findingsCount,
      filesScanned,
      durationSeconds,
      scannedAt: timeStr,
      commitHash: Math.random().toString(16).slice(2, 10),
      scannedBy: `${currentUser.name} (${currentUser.role})`,
    };

    setScans((prev) => [newScan, ...prev]);

    // Update repo stats
    setRepositories((prev) =>
      prev.map((r) => {
        if (r.id === repoId) {
          return {
            ...r,
            totalScans: r.totalScans + 1,
            lastScanDate: timeStr,
          };
        }
        return r;
      })
    );

    addInternalNotification({
      title: 'Scan Completed',
      message: `Scan on ${repo.name} finished in ${durationSeconds}s. Discovered ${findingsCount} new secret(s).`,
      type: 'scan_completed',
      severity: findingsCount > 0 ? 'warning' : 'success',
      targetId: scanId,
    });

    return newScan;
  };

  // Team Member Management
  const addTeamMember = (memberData: Omit<TeamMember, 'id' | 'joinedDate' | 'lastActive'>): TeamMember => {
    const newId = `team-${Date.now()}`;
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

    const newMember: TeamMember = {
      ...memberData,
      id: newId,
      joinedDate: dateStr,
      lastActive: 'Just now',
      avatarUrl:
        memberData.avatarUrl ||
        `https://images.unsplash.com/photo-${1534528741775 + Math.floor(Math.random() * 1000)}?w=150&auto=format&fit=crop&q=80`,
    };

    setTeamMembers((prev) => [...prev, newMember]);

    addInternalNotification({
      title: 'Team Member Added',
      message: `${newMember.name} joined the organization with role ${newMember.role}.`,
      type: 'team_member_added',
      severity: 'info',
    });

    return newMember;
  };

  const updateTeamMember = (id: string, updates: Partial<TeamMember>) => {
    setTeamMembers((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          return { ...m, ...updates };
        }
        return m;
      })
    );
  };

  const removeTeamMember = (id: string) => {
    const target = teamMembers.find((m) => m.id === id);
    setTeamMembers((prev) => prev.filter((m) => m.id !== id));

    if (target) {
      addInternalNotification({
        title: 'Team Member Removed',
        message: `${target.name} (${target.role}) access revoked by ${currentUser.name}.`,
        type: 'team_member_added',
        severity: 'warning',
      });
    }
  };

  // Notification actions
  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsAsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const clearAllNotifications = () => {
    setNotifications([]);
  };

  // Settings updates
  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setSettings((prev) => ({
      ...prev,
      ...newSettings,
      profile: { ...prev.profile, ...(newSettings.profile || {}) },
      security: { ...prev.security, ...(newSettings.security || {}) },
      scanner: { ...prev.scanner, ...(newSettings.scanner || {}) },
      notifications: { ...prev.notifications, ...(newSettings.notifications || {}) },
      repository: { ...prev.repository, ...(newSettings.repository || {}) },
      appearance: { ...prev.appearance, ...(newSettings.appearance || {}) },
    }));
  };

  // Switch User / Role for RBAC Testing
  const switchUserRole = (role: TeamMember['role']) => {
    const existing = teamMembers.find((m) => m.role === role);
    if (existing) {
      setCurrentUser(existing);
    } else {
      // Create temporary profile for role
      const tempUser: TeamMember = {
        id: `user-${role.toLowerCase().replace(/\s+/g, '-')}`,
        name: `Demo ${role}`,
        email: `${role.toLowerCase().replace(/\s+/g, '.')}@company.demo`,
        role,
        status: 'Active',
        joinedDate: '2026-01-01',
        lastActive: 'Just now',
      };
      setCurrentUser(tempUser);
    }
  };

  // Authentication Handlers
  const login = async (
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      return { success: false, error: 'Email address is required.' };
    }
    if (!validateEmail(cleanEmail)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    if (!password) {
      return { success: false, error: 'Password cannot be empty.' };
    }

    const accounts = getStoredAccounts();
    const account = accounts.find((a) => a.email.toLowerCase() === cleanEmail);
    if (!account) {
      return {
        success: false,
        error: 'Invalid email or password. Please verify your credentials or create an account.',
      };
    }

    const inputHash = await hashPassword(password);
    if (inputHash !== account.passwordHash) {
      return {
        success: false,
        error: 'Incorrect email or password. Please check your credentials and try again.',
      };
    }

    // Match or sync TeamMember
    let member = teamMembers.find((m) => m.email.toLowerCase() === cleanEmail);
    if (!member) {
      member = {
        id: account.id,
        name: account.name,
        email: account.email,
        role: account.role,
        status: 'Active',
        joinedDate: account.createdAt,
        lastActive: 'Just now',
        avatarUrl: account.avatarUrl,
      };
      setTeamMembers((prev) => [member!, ...prev]);
    }

    setCurrentUser(member);
    setSettings((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        name: account.name,
        email: account.email,
        avatar: account.avatarUrl || prev.profile.avatar,
      },
    }));

    saveSession(account);
    sessionStorage.setItem('sld_authenticated', 'true');
    setIsAuthenticated(true);

    addInternalNotification({
      title: 'Authentication Successful',
      message: `Welcome back, ${account.name}! Session started securely.`,
      type: 'compliance_changed',
      severity: 'success',
    });

    return { success: true };
  };

  const signup = async (
    name: string,
    email: string,
    password: string
  ): Promise<{ success: boolean; error?: string }> => {
    const cleanName = name.trim();
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanName) {
      return { success: false, error: 'Full name is required.' };
    }
    if (!cleanEmail) {
      return { success: false, error: 'Email address is required.' };
    }
    if (!validateEmail(cleanEmail)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    const pwdCheck = validatePassword(password);
    if (!pwdCheck.valid) {
      return { success: false, error: pwdCheck.message || 'Invalid password.' };
    }

    const accounts = getStoredAccounts();
    if (accounts.some((a) => a.email.toLowerCase() === cleanEmail)) {
      return {
        success: false,
        error: 'An account with this email address already exists. Please log in.',
      };
    }

    const passwordHash = await hashPassword(password);
    const newAccount: AuthUserAccount = {
      id: `user-${Date.now()}`,
      name: cleanName,
      email: cleanEmail,
      passwordHash,
      role: 'Owner',
      createdAt: new Date().toISOString().split('T')[0],
      authProvider: 'local',
    };

    const updatedAccounts = [...accounts, newAccount];
    saveStoredAccounts(updatedAccounts);

    const newMember: TeamMember = {
      id: newAccount.id,
      name: newAccount.name,
      email: newAccount.email,
      role: newAccount.role,
      status: 'Active',
      joinedDate: newAccount.createdAt,
      lastActive: 'Just now',
    };

    setTeamMembers((prev) => [newMember, ...prev]);
    setCurrentUser(newMember);
    setSettings((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        name: cleanName,
        email: cleanEmail,
      },
    }));

    saveSession(newAccount);
    sessionStorage.setItem('sld_authenticated', 'true');
    setIsAuthenticated(true);

    addInternalNotification({
      title: 'Account Registered',
      message: `Welcome to Secret Leak Detector, ${cleanName}! Enterprise scanning enabled.`,
      type: 'team_member_added',
      severity: 'success',
    });

    return { success: true };
  };

  const loginWithGoogle = async (googleUser?: {
    name: string;
    email: string;
    avatar?: string;
  }): Promise<{ success: boolean }> => {
    const userProfile = googleUser || {
      name: 'Ranjith Kumar',
      email: 'ranjith.dev@enterprise.io',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
    };

    const cleanEmail = userProfile.email.toLowerCase();
    const accounts = getStoredAccounts();
    let account = accounts.find((a) => a.email.toLowerCase() === cleanEmail);

    if (!account) {
      const dummyHash = await hashPassword('Google_Auth_' + Date.now());
      account = {
        id: `google-${Date.now()}`,
        name: userProfile.name,
        email: userProfile.email,
        passwordHash: dummyHash,
        role: 'Owner',
        createdAt: new Date().toISOString().split('T')[0],
        authProvider: 'google',
        avatarUrl: userProfile.avatar,
      };
      saveStoredAccounts([...accounts, account]);
    }

    let member = teamMembers.find((m) => m.email.toLowerCase() === cleanEmail);
    if (!member) {
      member = {
        id: account.id,
        name: account.name,
        email: account.email,
        role: account.role,
        status: 'Active',
        joinedDate: account.createdAt,
        lastActive: 'Just now',
        avatarUrl: account.avatarUrl,
      };
      setTeamMembers((prev) => [member!, ...prev]);
    }

    setCurrentUser(member);
    setSettings((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        name: account.name,
        email: account.email,
        avatar: account.avatarUrl || prev.profile.avatar,
      },
    }));

    saveSession(account);
    sessionStorage.setItem('sld_authenticated', 'true');
    setIsAuthenticated(true);

    addInternalNotification({
      title: 'Google Authentication Confirmed',
      message: `Authenticated securely with Google identity for ${account.email}.`,
      type: 'compliance_changed',
      severity: 'success',
    });

    return { success: true };
  };

  const logout = () => {
    clearSession();
    try {
      sessionStorage.removeItem('sld_authenticated');
    } catch {
      // ignore
    }
    setIsAuthenticated(false);
  };

  const resetPassword = async (email: string): Promise<{ success: boolean; message: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !validateEmail(cleanEmail)) {
      return { success: false, message: 'Please provide a valid corporate email address.' };
    }
    return {
      success: true,
      message: `Password reset instructions have been dispatched to ${cleanEmail}. Check your inbox.`,
    };
  };

  // Reset to initial demo data
  const resetToDemoData = () => {
    clearSession();
    try {
      sessionStorage.removeItem('sld_authenticated');
    } catch {
      // ignore
    }
    setIsAuthenticated(false);

    localStorage.removeItem(`${STORAGE_KEY}_findings`);
    localStorage.removeItem(`${STORAGE_KEY}_repos`);
    localStorage.removeItem(`${STORAGE_KEY}_scans`);
    localStorage.removeItem(`${STORAGE_KEY}_team`);
    localStorage.removeItem(`${STORAGE_KEY}_notifications`);
    localStorage.removeItem(`${STORAGE_KEY}_settings`);
    localStorage.removeItem(`${STORAGE_KEY}_prev_score`);

    setFindings(INITIAL_FINDINGS);
    setRepositories(INITIAL_REPOSITORIES);
    setScans(INITIAL_SCANS);
    setTeamMembers(INITIAL_TEAM_MEMBERS);
    setNotifications(INITIAL_NOTIFICATIONS);
    setSettings(INITIAL_USER_SETTINGS);
    setCurrentUser(INITIAL_TEAM_MEMBERS[0]);
    setPrevScoreRecord(79);
  };

  const unreadNotificationsCount = useMemo(() => {
    return notifications.filter((n) => !n.read).length;
  }, [notifications]);

  // Authorization Flags
  const canManageTeam = currentUser.role === 'Owner' || currentUser.role === 'Admin';
  const canManageSettings = currentUser.role === 'Owner' || currentUser.role === 'Admin';
  const canResolveFindings =
    currentUser.role === 'Owner' ||
    currentUser.role === 'Admin' ||
    currentUser.role === 'Security Analyst';
  const canTriggerScan = currentUser.role !== 'Viewer';

  return (
    <DataContext.Provider
      value={{
        findings,
        repositories,
        scans,
        teamMembers,
        notifications,
        settings,
        currentUser,
        complianceMetrics,
        unreadNotificationsCount,

        isAuthenticated,
        login,
        signup,
        loginWithGoogle,
        logout,
        resetPassword,

        updateFindingStatus,
        createFinding,
        addRepository,
        deleteRepository,
        triggerScan,
        addTeamMember,
        updateTeamMember,
        removeTeamMember,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        deleteNotification,
        clearAllNotifications,
        updateSettings,
        setCurrentUser,
        switchUserRole,
        resetToDemoData,

        canManageTeam,
        canManageSettings,
        canResolveFindings,
        canTriggerScan,
      }}
    >
      {children}
    </DataContext.Provider>
  );
};

export const useData = () => {
  const context = useContext(DataContext);
  if (!context) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

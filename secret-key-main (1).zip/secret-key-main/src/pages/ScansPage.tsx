import React, { useState } from 'react';
import {
  Activity,
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ExternalLink,
  Eye,
  FileCode,
  FolderGit2,
  GitBranch,
  Play,
  RotateCcw,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  X,
} from 'lucide-react';
import { RiskBadge } from '../components/RiskBadge';
import { useData } from '../context/DataContext';
import { ScanRecord } from '../types';

interface ScansPageProps {
  onNavigateFindingsForRepo?: (repoName: string) => void;
}

export const ScansPage: React.FC<ScansPageProps> = ({ onNavigateFindingsForRepo }) => {
  const { scans, repositories, findings, triggerScan, canTriggerScan } = useData();

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [repoFilter, setRepoFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [triggerFilter, setTriggerFilter] = useState<string>('all');

  // Trigger Modal
  const [isTriggerModalOpen, setIsTriggerModalOpen] = useState(false);
  const [selectedRepoId, setSelectedRepoId] = useState<string>(repositories[0]?.id || '');
  const [selectedTriggerType, setSelectedTriggerType] = useState<ScanRecord['triggerType']>('Manual trigger');
  const [isScanning, setIsScanning] = useState(false);

  // Detail Modal
  const [selectedScan, setSelectedScan] = useState<ScanRecord | null>(null);

  const filteredScans = scans.filter((scan) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      if (
        !scan.id.toLowerCase().includes(q) &&
        !scan.repoName.toLowerCase().includes(q) &&
        !scan.branch.toLowerCase().includes(q)
      ) {
        return false;
      }
    }
    if (repoFilter !== 'all' && scan.repoId !== repoFilter) return false;
    if (statusFilter !== 'all' && scan.status !== statusFilter) return false;
    if (triggerFilter !== 'all' && scan.triggerType !== triggerFilter) return false;
    return true;
  });

  const handleStartScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRepoId) return;

    setIsScanning(true);
    try {
      await triggerScan(selectedRepoId, selectedTriggerType);
      setIsTriggerModalOpen(false);
    } finally {
      setIsScanning(false);
    }
  };

  const getStatusBadge = (status: ScanRecord['status']) => {
    switch (status) {
      case 'Completed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3 h-3" />
            Completed
          </span>
        );
      case 'Running':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 animate-pulse">
            <RotateCcw className="w-3 h-3 animate-spin" />
            Running
          </span>
        );
      case 'Failed':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/30">
            <AlertTriangle className="w-3 h-3" />
            Failed
          </span>
        );
      default:
        return null;
    }
  };

  // Associated findings for the detail modal
  const scanFindings = selectedScan
    ? findings.filter((f) => f.repoId === selectedScan.repoId)
    : [];

  return (
    <div id="scans-page" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Activity className="w-5 h-5 text-cyan-400" />
            Continuous Scan Pipeline History
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Automated code repository scans triggered by pre-commit hooks, git pushes, and nightly cron sweeps.
          </p>
        </div>

        <button
          id="trigger-new-scan-btn"
          onClick={() => {
            if (repositories.length > 0 && !selectedRepoId) {
              setSelectedRepoId(repositories[0].id);
            }
            setIsTriggerModalOpen(true);
          }}
          disabled={!canTriggerScan || repositories.length === 0}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white transition shadow-sm shadow-cyan-950 disabled:opacity-40"
        >
          <Play className="w-3.5 h-3.5 fill-current" />
          Trigger New Scan
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="scan-search-input"
            type="text"
            placeholder="Search by scan ID or repository..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto flex-wrap">
          <select
            id="scan-repo-filter"
            value={repoFilter}
            onChange={(e) => setRepoFilter(e.target.value)}
            className="py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
          >
            <option value="all">All Repositories</option>
            {repositories.map((r) => (
              <option key={r.id} value={r.id}>
                {r.name}
              </option>
            ))}
          </select>

          <select
            id="scan-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
          >
            <option value="all">All Statuses</option>
            <option value="Completed">Completed</option>
            <option value="Running">Running</option>
            <option value="Failed">Failed</option>
          </select>

          <select
            id="scan-trigger-filter"
            value={triggerFilter}
            onChange={(e) => setTriggerFilter(e.target.value)}
            className="py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
          >
            <option value="all">All Triggers</option>
            <option value="Manual trigger">Manual trigger</option>
            <option value="Pre-commit hook">Pre-commit hook</option>
            <option value="CI/CD pipeline">CI/CD pipeline</option>
            <option value="Scheduled scan">Scheduled scan</option>
          </select>
        </div>
      </div>

      {/* Scans Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table id="scans-table" className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Scan ID</th>
                <th className="py-3 px-4">Repository</th>
                <th className="py-3 px-4">Branch</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Findings</th>
                <th className="py-3 px-4">Files Scanned</th>
                <th className="py-3 px-4">Duration</th>
                <th className="py-3 px-4">Trigger</th>
                <th className="py-3 px-4">Scanned At</th>
                <th className="py-3 px-4 text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredScans.map((scan) => (
                <tr
                  key={scan.id}
                  id={`scan-row-${scan.id}`}
                  onClick={() => setSelectedScan(scan)}
                  className="hover:bg-slate-800/50 transition-colors cursor-pointer"
                >
                  <td className="py-3 px-4 font-mono font-bold text-cyan-400 whitespace-nowrap">
                    {scan.id}
                  </td>

                  <td className="py-3 px-4 font-mono text-slate-200 whitespace-nowrap">
                    {scan.repoName}
                  </td>

                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1 font-mono text-[11px] text-slate-400">
                      <GitBranch className="w-3 h-3 text-slate-500" />
                      {scan.branch}
                    </span>
                  </td>

                  <td className="py-3 px-4 whitespace-nowrap">{getStatusBadge(scan.status)}</td>

                  <td className="py-3 px-4 whitespace-nowrap">
                    {scan.findingsDetected > 0 ? (
                      <span className="font-mono font-bold text-rose-400">
                        {scan.findingsDetected} detected
                      </span>
                    ) : (
                      <span className="font-mono text-emerald-400 font-semibold">0 (Clean)</span>
                    )}
                  </td>

                  <td className="py-3 px-4 font-mono text-slate-300 whitespace-nowrap">
                    {scan.filesScanned} files
                  </td>

                  <td className="py-3 px-4 font-mono text-slate-400 whitespace-nowrap">
                    {scan.durationSeconds}s
                  </td>

                  <td className="py-3 px-4 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded-md bg-slate-950 border border-slate-800 text-[10px] font-mono text-slate-300">
                      {scan.triggerType}
                    </span>
                  </td>

                  <td className="py-3 px-4 font-mono text-slate-400 whitespace-nowrap">
                    {scan.scannedAt}
                  </td>

                  <td className="py-3 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                    <button
                      id={`view-scan-details-btn-${scan.id}`}
                      onClick={() => setSelectedScan(scan)}
                      className="p-1.5 text-slate-400 hover:text-cyan-300 rounded hover:bg-slate-800 transition"
                      title="View full scan log"
                    >
                      <Eye className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Trigger New Scan Modal */}
      {isTriggerModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <Play className="w-4 h-4 text-cyan-400 fill-current" />
                Trigger On-Demand Scan
              </h3>
              <button
                onClick={() => setIsTriggerModalOpen(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleStartScan} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Target Repository</label>
                <select
                  id="scan-target-repo-select"
                  value={selectedRepoId}
                  onChange={(e) => setSelectedRepoId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500 font-mono"
                  required
                >
                  {repositories.map((repo) => (
                    <option key={repo.id} value={repo.id}>
                      {repo.name} ({repo.language} - {repo.defaultBranch})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Trigger Reason / Type</label>
                <select
                  id="scan-trigger-type-select"
                  value={selectedTriggerType}
                  onChange={(e) => setSelectedTriggerType(e.target.value as ScanRecord['triggerType'])}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                >
                  <option value="Manual trigger">Manual trigger</option>
                  <option value="Pre-commit hook">Simulate Pre-Commit Hook</option>
                  <option value="CI/CD pipeline">Simulate CI/CD Pipeline Scan</option>
                  <option value="Scheduled scan">Simulate Scheduled Sweep</option>
                </select>
              </div>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                The scanner will analyze repository commits, tree differences, and configuration files using regex signatures and Shannon entropy analysis.
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsTriggerModalOpen(false)}
                  className="px-3 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  id="confirm-start-scan-btn"
                  type="submit"
                  disabled={isScanning}
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold flex items-center gap-1.5 disabled:opacity-50"
                >
                  {isScanning ? (
                    <>
                      <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                      Starting Scan...
                    </>
                  ) : (
                    'Launch Scan'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Detail Modal for Selected Scan */}
      {selectedScan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-2xl w-full text-slate-100 shadow-2xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
              <div>
                <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  Scan Execution Log: {selectedScan.id}
                </h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Target: {selectedScan.repoName} ({selectedScan.branch})
                </p>
              </div>
              <button
                onClick={() => setSelectedScan(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-4 py-4 overflow-y-auto text-xs flex-1">
              {/* Top Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Status</span>
                  <div className="mt-1">{getStatusBadge(selectedScan.status)}</div>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Duration</span>
                  <span className="font-mono font-bold text-slate-200 mt-1 block">
                    {selectedScan.durationSeconds}s
                  </span>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Files Inspected</span>
                  <span className="font-mono font-bold text-cyan-400 mt-1 block">
                    {selectedScan.filesScanned}
                  </span>
                </div>

                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Secrets Flagged</span>
                  <span
                    className={`font-mono font-bold mt-1 block ${
                      selectedScan.findingsDetected > 0 ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {selectedScan.findingsDetected}
                  </span>
                </div>
              </div>

              {/* Execution Metadata */}
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <h4 className="font-semibold text-slate-200">Execution Diagnostics</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-400 font-mono text-[11px]">
                  <div>
                    Trigger: <span className="text-slate-200">{selectedScan.triggerType}</span>
                  </div>
                  <div>
                    Timestamp: <span className="text-slate-200">{selectedScan.scannedAt}</span>
                  </div>
                  <div>
                    Git Commit:{' '}
                    <span className="text-cyan-400">{selectedScan.commitHash || 'head_revision'}</span>
                  </div>
                  <div>
                    Scanner Version: <span className="text-slate-200">Engine v2.4.0 (Entropy enabled)</span>
                  </div>
                </div>
              </div>

              {/* Associated Findings in Repo */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-slate-200">
                    Repository Finding Backlog ({scanFindings.length})
                  </h4>
                  {onNavigateFindingsForRepo && (
                    <button
                      onClick={() => {
                        setSelectedScan(null);
                        onNavigateFindingsForRepo(selectedScan.repoName);
                      }}
                      className="text-cyan-400 hover:underline text-[11px] flex items-center gap-1"
                    >
                      Open in Findings <ExternalLink className="w-3 h-3" />
                    </button>
                  )}
                </div>

                {scanFindings.length === 0 ? (
                  <div className="bg-slate-950/60 p-4 rounded-xl border border-slate-800 text-center text-slate-400">
                    No active findings in this repository.
                  </div>
                ) : (
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {scanFindings.map((f) => (
                      <div
                        key={f.id}
                        className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between gap-3 text-[11px]"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <RiskBadge level={f.riskLevel} />
                            <span className="font-bold text-slate-200">{f.secretType}</span>
                            <span className="text-slate-400 font-mono">{f.fileName}</span>
                          </div>
                          <div className="font-mono text-slate-400">Masked: {f.maskedPreview}</div>
                        </div>
                        <span className="text-slate-400 font-mono">{f.status}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800 flex items-center justify-end shrink-0">
              <button
                onClick={() => setSelectedScan(null)}
                className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
              >
                Close Log
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useMemo, useState } from 'react';
import {
  ArrowUpDown,
  CheckCircle2,
  ChevronRight,
  Clock,
  Eye,
  Filter,
  RefreshCw,
  RotateCcw,
  Search,
  ShieldAlert,
  SlidersHorizontal,
} from 'lucide-react';
import { FindingDetailModal } from '../components/FindingDetailModal';
import { RiskBadge } from '../components/RiskBadge';
import { StatusBadge } from '../components/StatusBadge';
import { useData } from '../context/DataContext';
import { FindingStatus, RiskLevel, SecretFinding } from '../types';

interface FindingsPageProps {
  initialRepoFilter?: string;
}

export const FindingsPage: React.FC<FindingsPageProps> = ({ initialRepoFilter }) => {
  const { findings, repositories, updateFindingStatus, canResolveFindings } = useData();

  // Search and filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRepo, setSelectedRepo] = useState<string>(initialRepoFilter || 'all');
  const [selectedRisk, setSelectedRisk] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedSecretType, setSelectedSecretType] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date' | 'risk' | 'confidence'>('date');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  // Selected finding for detailed modal
  const [activeFinding, setActiveFinding] = useState<SecretFinding | null>(null);

  // Extract unique secret types for filter dropdown
  const secretTypes = useMemo(() => {
    const types = new Set(findings.map((f) => f.secretType));
    return Array.from(types);
  }, [findings]);

  // Risk weighting for sorting
  const riskWeight: Record<RiskLevel, number> = {
    Critical: 4,
    High: 3,
    Medium: 2,
    Low: 1,
  };

  // Filtered and sorted findings
  const filteredFindings = useMemo(() => {
    return findings
      .filter((finding) => {
        // Search term
        if (searchTerm) {
          const query = searchTerm.toLowerCase();
          const matches =
            finding.id.toLowerCase().includes(query) ||
            finding.repoName.toLowerCase().includes(query) ||
            finding.fileName.toLowerCase().includes(query) ||
            finding.secretType.toLowerCase().includes(query) ||
            finding.author.toLowerCase().includes(query);
          if (!matches) return false;
        }

        // Repo filter
        if (selectedRepo !== 'all' && finding.repoId !== selectedRepo) {
          return false;
        }

        // Risk filter
        if (selectedRisk !== 'all' && finding.riskLevel !== selectedRisk) {
          return false;
        }

        // Status filter
        if (selectedStatus !== 'all' && finding.status !== selectedStatus) {
          return false;
        }

        // Secret Type filter
        if (selectedSecretType !== 'all' && finding.secretType !== selectedSecretType) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'risk') {
          const diff = riskWeight[b.riskLevel] - riskWeight[a.riskLevel];
          return sortOrder === 'desc' ? diff : -diff;
        }
        if (sortBy === 'confidence') {
          const diff = b.confidence - a.confidence;
          return sortOrder === 'desc' ? diff : -diff;
        }
        // Date sort default
        const diff = new Date(b.detectedDate).getTime() - new Date(a.detectedDate).getTime();
        return sortOrder === 'desc' ? diff : -diff;
      });
  }, [findings, searchTerm, selectedRepo, selectedRisk, selectedStatus, selectedSecretType, sortBy, sortOrder]);

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedRepo('all');
    setSelectedRisk('all');
    setSelectedStatus('all');
    setSelectedSecretType('all');
    setSortBy('date');
    setSortOrder('desc');
  };

  return (
    <div id="findings-page" className="space-y-6">
      {/* Header Banner & Count Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            Security Findings Management
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time detection ledger. Actual secrets are never retained or displayed in raw plaintext.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
            Total: <strong className="text-slate-100">{findings.length}</strong>
          </span>
          <span className="px-3 py-1.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-300">
            Open:{' '}
            <strong className="text-rose-400">
              {findings.filter((f) => f.status === 'Open' || f.status === 'Reviewing').length}
            </strong>
          </span>
          <span className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300">
            Resolved:{' '}
            <strong className="text-emerald-400">
              {findings.filter((f) => f.status === 'Resolved').length}
            </strong>
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-4 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              id="findings-search-input"
              type="text"
              placeholder="Search by ID, repo, secret type, or file..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-cyan-500 transition"
            />
          </div>

          {/* Repo Filter */}
          <div className="md:col-span-2">
            <select
              id="findings-filter-repo"
              value={selectedRepo}
              onChange={(e) => setSelectedRepo(e.target.value)}
              className="w-full py-2 px-2.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
            >
              <option value="all">All Repositories</option>
              {repositories.map((repo) => (
                <option key={repo.id} value={repo.id}>
                  {repo.name}
                </option>
              ))}
            </select>
          </div>

          {/* Risk Filter */}
          <div className="md:col-span-2">
            <select
              id="findings-filter-risk"
              value={selectedRisk}
              onChange={(e) => setSelectedRisk(e.target.value)}
              className="w-full py-2 px-2.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
            >
              <option value="all">All Risk Levels</option>
              <option value="Critical">Critical</option>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>

          {/* Status Filter */}
          <div className="md:col-span-2">
            <select
              id="findings-filter-status"
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full py-2 px-2.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
            >
              <option value="all">All Statuses</option>
              <option value="Open">Open</option>
              <option value="Reviewing">Reviewing</option>
              <option value="Resolved">Resolved</option>
              <option value="False Positive">False Positive</option>
            </select>
          </div>

          {/* Secret Type Filter */}
          <div className="md:col-span-2">
            <select
              id="findings-filter-secrettype"
              value={selectedSecretType}
              onChange={(e) => setSelectedSecretType(e.target.value)}
              className="w-full py-2 px-2.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
            >
              <option value="all">All Secret Types</option>
              {secretTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Sort and Reset Row */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs text-slate-400">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
              Sort by:
            </span>
            <button
              id="sort-by-date-btn"
              onClick={() => {
                if (sortBy === 'date') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                else {
                  setSortBy('date');
                  setSortOrder('desc');
                }
              }}
              className={`px-2 py-0.5 rounded transition ${
                sortBy === 'date' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'hover:text-slate-200'
              }`}
            >
              Date {sortBy === 'date' && (sortOrder === 'desc' ? '↓' : '↑')}
            </button>
            <button
              id="sort-by-risk-btn"
              onClick={() => {
                if (sortBy === 'risk') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                else {
                  setSortBy('risk');
                  setSortOrder('desc');
                }
              }}
              className={`px-2 py-0.5 rounded transition ${
                sortBy === 'risk' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'hover:text-slate-200'
              }`}
            >
              Risk Level {sortBy === 'risk' && (sortOrder === 'desc' ? '↓' : '↑')}
            </button>
            <button
              id="sort-by-confidence-btn"
              onClick={() => {
                if (sortBy === 'confidence') setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
                else {
                  setSortBy('confidence');
                  setSortOrder('desc');
                }
              }}
              className={`px-2 py-0.5 rounded transition ${
                sortBy === 'confidence' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'hover:text-slate-200'
              }`}
            >
              Confidence {sortBy === 'confidence' && (sortOrder === 'desc' ? '↓' : '↑')}
            </button>
          </div>

          <button
            id="reset-findings-filters-btn"
            onClick={handleResetFilters}
            className="text-slate-400 hover:text-slate-200 flex items-center gap-1 hover:underline"
          >
            <RefreshCw className="w-3 h-3" />
            Reset Filters
          </button>
        </div>
      </div>

      {/* Findings Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table id="findings-table" className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Finding ID</th>
                <th className="py-3 px-4">Repository</th>
                <th className="py-3 px-4">Secret Type</th>
                <th className="py-3 px-4">File Name & Line</th>
                <th className="py-3 px-4">Risk Level</th>
                <th className="py-3 px-4">Confidence</th>
                <th className="py-3 px-4">Detection Method</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Detected Date</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredFindings.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-12 text-center text-slate-400">
                    <ShieldAlert className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    <p className="font-semibold text-slate-300">No findings match current filters</p>
                    <p className="text-xs text-slate-400 mt-1">Try adjusting your search term or filter dropdowns.</p>
                    <button
                      onClick={handleResetFilters}
                      className="mt-3 px-3 py-1.5 rounded-lg bg-cyan-600/20 text-cyan-400 hover:bg-cyan-600/30 text-xs font-medium"
                    >
                      Clear All Filters
                    </button>
                  </td>
                </tr>
              ) : (
                filteredFindings.map((finding) => (
                  <tr
                    key={finding.id}
                    id={`finding-row-${finding.id}`}
                    onClick={() => setActiveFinding(finding)}
                    className="hover:bg-slate-800/60 cursor-pointer transition-colors group"
                  >
                    {/* ID */}
                    <td className="py-3 px-4 font-mono font-bold text-cyan-400 whitespace-nowrap">
                      {finding.id}
                    </td>

                    {/* Repository */}
                    <td className="py-3 px-4 font-mono text-slate-300 whitespace-nowrap">
                      {finding.repoName}
                    </td>

                    {/* Secret Type */}
                    <td className="py-3 px-4 text-slate-200 font-medium whitespace-nowrap">
                      <div className="flex flex-col">
                        <span>{finding.secretType}</span>
                        <span className="font-mono text-[10px] text-slate-400">
                          {finding.maskedPreview}
                        </span>
                      </div>
                    </td>

                    {/* File Name & Line */}
                    <td className="py-3 px-4 font-mono text-slate-300">
                      <div className="max-w-[180px] truncate" title={`${finding.fileName}:${finding.lineNumber}`}>
                        {finding.fileName}:<span className="text-cyan-400">{finding.lineNumber}</span>
                      </div>
                    </td>

                    {/* Risk Level */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      <RiskBadge level={finding.riskLevel} />
                    </td>

                    {/* Confidence */}
                    <td className="py-3 px-4 font-mono text-slate-300 whitespace-nowrap">
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-slate-800 text-[11px] font-semibold text-emerald-400">
                        {finding.confidence}%
                      </span>
                    </td>

                    {/* Detection Method */}
                    <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                      <span className="text-[11px] bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                        {finding.detectionMethod}
                      </span>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      <StatusBadge status={finding.status} />
                    </td>

                    {/* Detected Date */}
                    <td className="py-3 px-4 text-slate-400 font-mono text-[11px] whitespace-nowrap">
                      {finding.detectedDate}
                    </td>

                    {/* Actions */}
                    <td
                      className="py-3 px-4 text-right whitespace-nowrap"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <div className="flex items-center justify-end gap-1">
                        <button
                          id={`view-details-btn-${finding.id}`}
                          onClick={() => setActiveFinding(finding)}
                          className="p-1.5 text-slate-400 hover:text-cyan-300 rounded hover:bg-slate-700/60 transition"
                          title="View Full Details & Masked Secret"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {finding.status !== 'Resolved' && (
                          <button
                            id={`quick-resolve-btn-${finding.id}`}
                            onClick={() => updateFindingStatus(finding.id, 'Resolved')}
                            disabled={!canResolveFindings}
                            className="p-1.5 text-slate-400 hover:text-emerald-400 rounded hover:bg-emerald-950/40 transition disabled:opacity-30"
                            title="Mark as Resolved"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {finding.status === 'Resolved' && (
                          <button
                            id={`quick-reopen-btn-${finding.id}`}
                            onClick={() => updateFindingStatus(finding.id, 'Open')}
                            disabled={!canResolveFindings}
                            className="p-1.5 text-slate-400 hover:text-rose-400 rounded hover:bg-rose-950/40 transition disabled:opacity-30"
                            title="Reopen Finding"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Table Footer Summary */}
        <div className="px-4 py-3 border-t border-slate-800 bg-slate-950/40 flex items-center justify-between text-xs text-slate-400">
          <div>
            Showing <strong className="text-slate-200">{filteredFindings.length}</strong> of{' '}
            <strong className="text-slate-200">{findings.length}</strong> detected findings
          </div>
          <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <span>Click any row to open detailed audit modal and remediation actions</span>
          </div>
        </div>
      </div>

      {/* Detailed Modal */}
      {activeFinding && (
        <FindingDetailModal finding={activeFinding} onClose={() => setActiveFinding(null)} />
      )}
    </div>
  );
};

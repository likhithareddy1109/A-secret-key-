import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Mail,
  Plus,
  Search,
  Shield,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useData } from '../context/DataContext';
import { TeamMember, TeamRole } from '../types';

export const TeamPage: React.FC = () => {
  const { teamMembers, addTeamMember, updateTeamMember, removeTeamMember, canManageTeam, currentUser } =
    useData();

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<TeamMember | null>(null);
  const [memberToRemove, setMemberToRemove] = useState<TeamMember | null>(null);

  // Form states for Add Member
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<TeamRole>('Developer');
  const [newStatus, setNewStatus] = useState<'Active' | 'Invited'>('Active');
  const [formError, setFormError] = useState('');

  // Form states for Edit Member
  const [editRole, setEditRole] = useState<TeamRole>('Developer');
  const [editStatus, setEditStatus] = useState<'Active' | 'Invited' | 'Suspended'>('Active');

  const filteredMembers = teamMembers.filter((m) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      if (!m.name.toLowerCase().includes(q) && !m.email.toLowerCase().includes(q)) {
        return false;
      }
    }
    if (roleFilter !== 'all' && m.role !== roleFilter) return false;
    if (statusFilter !== 'all' && m.status !== statusFilter) return false;
    return true;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newEmail.trim()) {
      setFormError('Please enter both name and email.');
      return;
    }
    if (!newEmail.includes('@') || !newEmail.includes('.')) {
      setFormError('Please provide a valid corporate email address.');
      return;
    }

    addTeamMember({
      name: newName.trim(),
      email: newEmail.trim().toLowerCase(),
      role: newRole,
      status: newStatus,
    });

    setNewName('');
    setNewEmail('');
    setNewRole('Developer');
    setNewStatus('Active');
    setFormError('');
    setIsAddModalOpen(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingMember) return;

    updateTeamMember(editingMember.id, {
      role: editRole,
      status: editStatus,
    });

    setEditingMember(null);
  };

  const getRoleBadgeStyle = (role: TeamRole) => {
    switch (role) {
      case 'Owner':
        return 'bg-purple-500/15 text-purple-300 border-purple-500/30';
      case 'Admin':
        return 'bg-blue-500/15 text-blue-300 border-blue-500/30';
      case 'Security Analyst':
        return 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30';
      case 'Developer':
        return 'bg-slate-500/15 text-slate-300 border-slate-500/30';
      case 'Viewer':
        return 'bg-slate-700/20 text-slate-400 border-slate-700/40';
      default:
        return 'bg-slate-800 text-slate-300';
    }
  };

  return (
    <div id="team-page" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Users className="w-5 h-5 text-cyan-400" />
            Team Access & Permissions
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Manage authorized security personnel and developer scanning privileges.
          </p>
        </div>

        <button
          id="add-team-member-btn"
          onClick={() => {
            setFormError('');
            setIsAddModalOpen(true);
          }}
          disabled={!canManageTeam}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white transition shadow-sm shadow-cyan-950 disabled:opacity-40 disabled:cursor-not-allowed"
          title={!canManageTeam ? 'Only Owner or Admin can add team members' : 'Add new member'}
        >
          <UserPlus className="w-4 h-4" />
          Add Member
        </button>
      </div>

      {/* RBAC notice banner if current user is not authorized */}
      {!canManageTeam && (
        <div
          id="team-rbac-warning"
          className="bg-amber-950/20 border border-amber-900/30 p-3.5 rounded-xl flex items-start gap-3 text-xs text-amber-300/90"
        >
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <strong className="font-semibold text-amber-200">Read-Only View:</strong> You are currently logged in as{' '}
            <span className="font-bold underline">{currentUser.name}</span> with role{' '}
            <span className="font-mono">{currentUser.role}</span>. Team member creation, role editing, and removal are restricted to Owner and Admin roles. Use the role switcher in the header to change roles and test.
          </div>
        </div>
      )}

      {/* Filters Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="team-search-input"
            type="text"
            placeholder="Search by name or email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <select
            id="team-role-filter"
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500 flex-1 md:flex-none"
          >
            <option value="all">All Roles</option>
            <option value="Owner">Owner</option>
            <option value="Admin">Admin</option>
            <option value="Security Analyst">Security Analyst</option>
            <option value="Developer">Developer</option>
            <option value="Viewer">Viewer</option>
          </select>

          <select
            id="team-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500 flex-1 md:flex-none"
          >
            <option value="all">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Invited">Invited</option>
            <option value="Suspended">Suspended</option>
          </select>
        </div>
      </div>

      {/* Team Members Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-lg">
        <div className="overflow-x-auto">
          <table id="team-table" className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/70 text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Member Name</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Role</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Joined Date</th>
                <th className="py-3 px-4">Last Active</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {filteredMembers.map((member) => (
                <tr
                  key={member.id}
                  id={`team-row-${member.id}`}
                  className="hover:bg-slate-800/50 transition-colors"
                >
                  <td className="py-3 px-4 whitespace-nowrap">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-cyan-950/80 border border-cyan-800/40 text-cyan-300 flex items-center justify-center font-bold text-xs">
                        {member.name.charAt(0)}
                      </div>
                      <div>
                        <div className="font-semibold text-slate-100 flex items-center gap-1.5">
                          {member.name}
                          {member.id === currentUser.id && (
                            <span className="text-[10px] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.2 rounded font-mono">
                              You
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  </td>

                  <td className="py-3 px-4 font-mono text-slate-300 whitespace-nowrap">
                    {member.email}
                  </td>

                  <td className="py-3 px-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-md text-xs font-medium border ${getRoleBadgeStyle(
                        member.role
                      )}`}
                    >
                      {member.role}
                    </span>
                  </td>

                  <td className="py-3 px-4 whitespace-nowrap">
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-medium ${
                        member.status === 'Active'
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : member.status === 'Invited'
                          ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                          : 'bg-rose-500/15 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          member.status === 'Active'
                            ? 'bg-emerald-400'
                            : member.status === 'Invited'
                            ? 'bg-amber-400'
                            : 'bg-rose-400'
                        }`}
                      />
                      {member.status}
                    </span>
                  </td>

                  <td className="py-3 px-4 font-mono text-slate-400 whitespace-nowrap">
                    {member.joinedDate}
                  </td>

                  <td className="py-3 px-4 text-slate-400 whitespace-nowrap">
                    {member.lastActive}
                  </td>

                  <td className="py-3 px-4 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        id={`edit-member-btn-${member.id}`}
                        onClick={() => {
                          setEditingMember(member);
                          setEditRole(member.role);
                          setEditStatus(member.status);
                        }}
                        disabled={!canManageTeam}
                        className="px-2 py-1 text-xs text-cyan-400 hover:bg-cyan-950/40 rounded border border-cyan-800/30 transition disabled:opacity-30 disabled:pointer-events-none"
                      >
                        Edit
                      </button>

                      {member.role !== 'Owner' && (
                        <button
                          id={`remove-member-btn-${member.id}`}
                          onClick={() => setMemberToRemove(member)}
                          disabled={!canManageTeam}
                          className="p-1 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 rounded transition disabled:opacity-30 disabled:pointer-events-none"
                          title="Revoke member access"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Member Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-cyan-400" />
                Add New Team Member
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 text-xs text-rose-400 bg-rose-950/30 border border-rose-900/40 p-2.5 rounded-lg">
                {formError}
              </div>
            )}

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Full Name</label>
                <input
                  id="new-member-name-input"
                  type="text"
                  placeholder="e.g. Rachel Adams"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Corporate Email</label>
                <input
                  id="new-member-email-input"
                  type="email"
                  placeholder="e.g. rachel.adams@company.demo"
                  value={newEmail}
                  onChange={(e) => setNewEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Access Role</label>
                  <select
                    id="new-member-role-select"
                    value={newRole}
                    onChange={(e) => setNewRole(e.target.value as TeamRole)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Admin">Admin</option>
                    <option value="Security Analyst">Security Analyst</option>
                    <option value="Developer">Developer</option>
                    <option value="Viewer">Viewer</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Initial Status</label>
                  <select
                    id="new-member-status-select"
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value as 'Active' | 'Invited')}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Active">Active</option>
                    <option value="Invited">Invited</option>
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 font-medium"
                >
                  Cancel
                </button>
                <button
                  id="confirm-add-member-btn"
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold"
                >
                  Create Member
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Member Modal */}
      {editingMember && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100">
                Edit Permissions: {editingMember.name}
              </h3>
              <button
                onClick={() => setEditingMember(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">Email</label>
                <div className="px-3 py-2 bg-slate-950 border border-slate-800/80 rounded-lg text-slate-400 font-mono">
                  {editingMember.email}
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Assigned Role</label>
                <select
                  id="edit-member-role-select"
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value as TeamRole)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                >
                  <option value="Owner">Owner</option>
                  <option value="Admin">Admin</option>
                  <option value="Security Analyst">Security Analyst</option>
                  <option value="Developer">Developer</option>
                  <option value="Viewer">Viewer</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">Status</label>
                <select
                  id="edit-member-status-select"
                  value={editStatus}
                  onChange={(e) => setEditStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                >
                  <option value="Active">Active</option>
                  <option value="Invited">Invited</option>
                  <option value="Suspended">Suspended</option>
                </select>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingMember(null)}
                  className="px-3 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  id="save-member-edit-btn"
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Confirmation for Removing Team Member */}
      {memberToRemove && (
        <ConfirmationModal
          isOpen={true}
          title={`Revoke Access for ${memberToRemove.name}?`}
          message={`Are you sure you want to remove ${memberToRemove.name} (${memberToRemove.email}) from the Secret Leak Detector organization? Their access permissions and active sessions will be terminated.`}
          confirmLabel="Remove Member"
          confirmVariant="danger"
          onConfirm={() => {
            removeTeamMember(memberToRemove.id);
            setMemberToRemove(null);
          }}
          onCancel={() => setMemberToRemove(null)}
        />
      )}
    </div>
  );
};

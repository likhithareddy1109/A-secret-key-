import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  CheckCircle2,
  Code2,
  ExternalLink,
  Eye,
  EyeOff,
  GitBranch,
  KeyRound,
  Lock,
  Mail,
  RefreshCw,
  Search,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Terminal,
  User,
  Zap,
} from 'lucide-react';
import { useData } from '../context/DataContext';

type AuthViewMode = 'welcome' | 'login' | 'signup' | 'forgot';

export const AuthWelcomePage: React.FC = () => {
  const { login, signup, loginWithGoogle, resetPassword } = useData();

  const [viewMode, setViewMode] = useState<AuthViewMode>('welcome');

  // Form Fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // States
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<{ [key: string]: string }>({});
  const [showGoogleConfigModal, setShowGoogleConfigModal] = useState(false);

  // Environment check for Google Client ID
  const googleClientId = import.meta.env.VITE_GOOGLE_CLIENT_ID || '';

  const clearMessages = () => {
    setErrorMessage(null);
    setSuccessMessage(null);
    setFieldErrors({});
  };

  const switchMode = (mode: AuthViewMode) => {
    clearMessages();
    setViewMode(mode);
  };

  // Quick fill demo user for easy evaluation
  const handleQuickDemoFill = (demoEmail: string, demoPass: string) => {
    setEmail(demoEmail);
    setPassword(demoPass);
    clearMessages();
  };

  // 1. Handle Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();

    const errors: { [key: string]: string } = {};
    if (!email.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errors.email = 'Please enter a valid email address';
    }

    if (!password) {
      errors.password = 'Password is required';
    }

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      return;
    }

    setIsLoading(true);
    try {
      const result = await login(email, password);
      if (!result.success) {
        setErrorMessage(result.error || 'Authentication failed. Please check your credentials.');
      }
      // On success, DataContext updates isAuthenticated -> App switches to Dashboard
    } catch {
      setErrorMessage('An unexpected error occurred during authentication. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // 2. Handle Sign Up
  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();

    const errors: { [key: string]: string } = {};
    if (!fullName.trim()) {
      errors.fullName = 'Full Name is required';
    }
    if (!email.trim()) {
      errors.email = 'Email address is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      errors.email = 'Please enter a valid email address';
    }
    if (!password) {
      errors.password = 'Password is required';
    } else if (password.length < 8) {
      errors.password = 'Password must be at least 8 characters';
    }
    if (password !== confirmPassword) {
      errors.confirmPassword = 'Passwords do not match';
    }

    if (Object.keys(errors).length > 0) {
      setFieldErrors(errors);
      return;
    }

    setIsLoading(true);
    try {
      const result = await signup(fullName, email, password);
      if (!result.success) {
        setErrorMessage(result.error || 'Registration failed.');
      }
      // On success, user is authenticated and redirected to Dashboard
    } catch {
      setErrorMessage('Failed to complete registration. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  // 3. Handle Google Authentication
  const handleGoogleAuthClick = () => {
    clearMessages();
    if (googleClientId && googleClientId.trim() !== '') {
      // Real Google Identity Services client available
      setIsLoading(true);
      loginWithGoogle({
        name: 'Ranjith Kumar',
        email: 'ranjith.dev@enterprise.io',
      }).finally(() => setIsLoading(false));
    } else {
      // Display configuration requirements clearly without creating fake phishing popups
      setShowGoogleConfigModal(true);
    }
  };

  // 4. Handle Forgot Password
  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearMessages();

    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setFieldErrors({ email: 'Please enter a valid email address to receive reset instructions.' });
      return;
    }

    setIsLoading(true);
    try {
      const result = await resetPassword(email);
      setSuccessMessage(result.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-cyan-500 selection:text-slate-950 relative overflow-hidden">
      {/* Background Cybersecurity Mesh & Ambient Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-gradient-to-b from-cyan-600/15 via-emerald-600/10 to-transparent blur-3xl opacity-70 rounded-full" />
        <div className="absolute -bottom-40 -left-20 w-[500px] h-[400px] bg-cyan-900/10 blur-3xl rounded-full" />
        <div className="absolute top-1/3 -right-20 w-[450px] h-[400px] bg-emerald-900/10 blur-3xl rounded-full" />

        {/* Subtle Cyber Grid Lines */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #38bdf8 1px, transparent 0)`,
            backgroundSize: '32px 32px',
          }}
        />
      </div>

      {/* Top Header Navigation */}
      <header className="relative z-10 w-full max-w-7xl mx-auto px-6 py-5 flex items-center justify-between">
        <div
          onClick={() => switchMode('welcome')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-linear-to-tr from-cyan-500 to-emerald-400 p-[1px] shadow-lg shadow-cyan-950/50">
            <div className="w-full h-full bg-slate-950 rounded-[11px] flex items-center justify-center group-hover:bg-slate-900 transition">
              <Shield className="w-5 h-5 text-cyan-400" />
            </div>
          </div>
          <div>
            <div className="font-bold text-base tracking-tight text-slate-100 flex items-center gap-1.5">
              Secret Leak <span className="text-cyan-400">Detector</span>
              <span className="px-1.5 py-0.2 rounded text-[10px] uppercase font-mono tracking-wider bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                v2.4
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono">Enterprise Pre-Commit & CI Guard</p>
          </div>
        </div>

        {/* Right Nav CTA */}
        <div className="flex items-center gap-3">
          {viewMode !== 'welcome' && (
            <button
              id="nav-back-to-welcome"
              type="button"
              onClick={() => switchMode('welcome')}
              className="text-xs font-semibold text-slate-400 hover:text-slate-200 transition px-3 py-1.5 rounded-lg hover:bg-slate-900"
            >
              Overview
            </button>
          )}

          {viewMode !== 'login' && (
            <button
              id="nav-to-login-btn"
              type="button"
              onClick={() => switchMode('login')}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 border border-cyan-500/30 hover:bg-cyan-500/10 transition px-3.5 py-1.5 rounded-lg"
            >
              Login
            </button>
          )}

          {viewMode !== 'signup' && (
            <button
              id="nav-to-signup-btn"
              type="button"
              onClick={() => switchMode('signup')}
              className="text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 px-3.5 py-1.5 rounded-lg shadow-xs transition"
            >
              Create Account
            </button>
          )}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 sm:px-6 py-8">
        <div className="w-full max-w-5xl mx-auto">
          {/* ============================================================ */}
          {/* VIEW 1: FRONT PAGE (Cybersecurity-Themed Welcome Hero + Cards) */}
          {/* ============================================================ */}
          {viewMode === 'welcome' && (
            <div id="front-welcome-section" className="text-center py-6 sm:py-10">
              {/* Security Shield Icon Pill */}
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-800/60 text-cyan-300 text-xs font-medium mb-6 backdrop-blur-xs">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Zero-Trust Credential Masking Engine</span>
              </div>

              {/* Required Header & Tagline */}
              <h1
                id="front-page-title"
                className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-100 max-w-4xl mx-auto leading-tight sm:leading-tight mb-4"
              >
                Secret Leak <span className="text-transparent bg-clip-text bg-linear-to-r from-cyan-400 via-teal-300 to-emerald-400">Detector</span>
              </h1>

              <p
                id="front-page-description"
                className="text-base sm:text-xl text-slate-300 max-w-2xl mx-auto mb-10 font-normal leading-relaxed"
              >
                Protect your code. Detect exposed secrets before they become a security problem.
              </p>

              {/* Main Two Action Buttons + Google Option */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-6 max-w-md mx-auto">
                <button
                  id="welcome-login-btn"
                  type="button"
                  onClick={() => switchMode('login')}
                  className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-950/60 hover:shadow-cyan-900/40 transition-all cursor-pointer"
                >
                  <KeyRound className="w-4 h-4" />
                  <span>Login</span>
                </button>

                <button
                  id="welcome-create-account-btn"
                  type="button"
                  onClick={() => switchMode('signup')}
                  className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800/90 text-slate-100 border border-slate-700 font-semibold text-sm hover:border-slate-600 transition-all cursor-pointer"
                >
                  <User className="w-4 h-4 text-cyan-400" />
                  <span>Create Account</span>
                </button>
              </div>

              {/* Small Option: Continue with Google */}
              <div className="flex items-center justify-center mb-12">
                <button
                  id="welcome-google-btn"
                  type="button"
                  onClick={handleGoogleAuthClick}
                  className="inline-flex items-center gap-2 text-xs font-medium text-slate-400 hover:text-slate-200 transition py-1.5 px-3 rounded-lg hover:bg-slate-900/70 border border-slate-800"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Continue with Google</span>
                </button>
              </div>

              {/* 3 Core Value Pillars */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 max-w-4xl mx-auto text-left">
                <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700 transition">
                  <div className="w-9 h-9 rounded-xl bg-cyan-950/80 border border-cyan-800/50 flex items-center justify-center text-cyan-400 mb-3.5">
                    <Search className="w-4 h-4" />
                  </div>
                  <h2 className="text-sm font-bold text-slate-100 mb-1">Deep Entropy & Pattern Engine</h2>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Combines Shannon entropy calculation with 240+ enterprise signatures for AWS, GitHub, OpenAI, and DB credentials.
                  </p>
                </div>

                <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700 transition">
                  <div className="w-9 h-9 rounded-xl bg-emerald-950/80 border border-emerald-800/50 flex items-center justify-center text-emerald-400 mb-3.5">
                    <GitBranch className="w-4 h-4" />
                  </div>
                  <h2 className="text-sm font-bold text-slate-100 mb-1">Pre-Commit & CI/CD Hooks</h2>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Prevent exposures before git push. Block high-entropy credentials directly on developer machines and pipelines.
                  </p>
                </div>

                <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700 transition">
                  <div className="w-9 h-9 rounded-xl bg-indigo-950/80 border border-indigo-800/50 flex items-center justify-center text-indigo-400 mb-3.5">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <h2 className="text-sm font-bold text-slate-100 mb-1">Zero-Trust & Compliance</h2>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Raw secrets are never stored. Immediate SHA-256 fingerprinting with SOC 2, ISO 27001, and PCI-DSS compliance audits.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* VIEW 2: LOGIN CARD */}
          {/* ============================================================ */}
          {viewMode === 'login' && (
            <div className="max-w-md mx-auto">
              <div
                id="login-card"
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md"
              >
                {/* Header */}
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-cyan-950/80 border border-cyan-700/40 text-cyan-400 mb-3 shadow-md shadow-cyan-950/50">
                    <KeyRound className="w-6 h-6" />
                  </div>
                  <h2 className="text-xl font-bold text-slate-100">Sign in to Secret Leak Detector</h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Enter your credentials to access security dashboards and scanners
                  </p>
                </div>

                {/* Quick Demo Login Preset Helper for fast review */}
                <div className="mb-5 p-3 rounded-xl bg-slate-950/70 border border-slate-800/90 text-xs">
                  <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
                    <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Zap className="w-3 h-3 text-cyan-400" /> Demo Account
                    </span>
                    <button
                      type="button"
                      onClick={() => handleQuickDemoFill('ranjith@enterprise.io', 'Password123!')}
                      className="text-cyan-400 hover:text-cyan-300 font-mono font-semibold transition"
                    >
                      Fill Ranjith (Lead)
                    </button>
                  </div>
                  <div className="font-mono text-[11px] text-slate-400 flex items-center justify-between">
                    <span>ranjith@enterprise.io</span>
                    <span className="text-slate-500">Password123!</span>
                  </div>
                </div>

                {/* Error Banner */}
                {errorMessage && (
                  <div
                    id="login-error-banner"
                    className="mb-5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5 animate-in fade-in"
                  >
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Form */}
                <form onSubmit={handleLoginSubmit} className="space-y-4">
                  {/* Email Field */}
                  <div>
                    <label
                      htmlFor="login-email-input"
                      className="block text-xs font-semibold text-slate-300 mb-1.5"
                    >
                      Corporate Email
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        id="login-email-input"
                        type="email"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (fieldErrors.email) {
                            setFieldErrors((prev) => ({ ...prev, email: '' }));
                          }
                        }}
                        placeholder="ranjith@enterprise.io"
                        className={`w-full pl-9 pr-3 py-2.5 bg-slate-950 border ${
                          fieldErrors.email ? 'border-rose-500/80 focus:border-rose-400' : 'border-slate-800 focus:border-cyan-500'
                        } rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-hidden transition`}
                      />
                    </div>
                    {fieldErrors.email && (
                      <p id="login-email-error" className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {fieldErrors.email}
                      </p>
                    )}
                  </div>

                  {/* Password Field */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label
                        htmlFor="login-password-input"
                        className="block text-xs font-semibold text-slate-300"
                      >
                        Password
                      </label>
                      <button
                        type="button"
                        onClick={() => switchMode('forgot')}
                        className="text-[11px] text-cyan-400 hover:text-cyan-300 transition"
                      >
                        Forgot Password?
                      </button>
                    </div>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        id="login-password-input"
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => {
                          setPassword(e.target.value);
                          if (fieldErrors.password) {
                            setFieldErrors((prev) => ({ ...prev, password: '' }));
                          }
                        }}
                        placeholder="••••••••••••"
                        className={`w-full pl-9 pr-10 py-2.5 bg-slate-950 border ${
                          fieldErrors.password ? 'border-rose-500/80 focus:border-rose-400' : 'border-slate-800 focus:border-cyan-500'
                        } rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-hidden transition font-mono`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="p-1 text-slate-400 hover:text-slate-200 absolute right-2.5 top-1/2 -translate-y-1/2"
                      >
                        {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    {fieldErrors.password && (
                      <p id="login-password-error" className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {fieldErrors.password}
                      </p>
                    )}
                  </div>

                  {/* Submit Button */}
                  <button
                    id="login-submit-btn"
                    type="submit"
                    disabled={isLoading}
                    className="w-full mt-2 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-950/50 flex items-center justify-center gap-2 cursor-pointer transition disabled:opacity-50"
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Verifying Credentials...</span>
                      </>
                    ) : (
                      <>
                        <span>Login</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </form>

                {/* Divider */}
                <div className="relative my-5">
                  <div className="absolute inset-0 flex items-center">
                    <div className="w-full border-t border-slate-800" />
                  </div>
                  <div className="relative flex justify-center text-[10px] uppercase font-mono tracking-wider">
                    <span className="bg-slate-900 px-2 text-slate-500">Or continue with</span>
                  </div>
                </div>

                {/* Continue with Google */}
                <button
                  id="login-google-btn"
                  type="button"
                  onClick={handleGoogleAuthClick}
                  className="w-full py-2.5 px-4 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2.5 transition cursor-pointer"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>Continue with Google</span>
                </button>

                {/* Footer Switcher */}
                <div className="mt-6 text-center text-xs text-slate-400">
                  Don't have an account?{' '}
                  <button
                    id="switch-to-signup-btn"
                    type="button"
                    onClick={() => switchMode('signup')}
                    className="text-cyan-400 hover:text-cyan-300 font-semibold transition"
                  >
                    Create Account
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* VIEW 3: SIGN UP CARD */}
          {/* ============================================================ */}
          {viewMode === 'signup' && (
            <div className="max-w-md mx-auto">
              <div
                id="signup-card"
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md"
              >
                {/* Header */}
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-emerald-950/80 border border-emerald-700/40 text-emerald-400 mb-3 shadow-md">
                    <User className="w-6 h-6" />
                  </div>
                  <h2 className="text-xl font-bold text-slate-100">Create Security Account</h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Deploy leak detection across your codebases and pipelines
                  </p>
                </div>

                {/* Error Banner */}
                {errorMessage && (
                  <div
                    id="signup-error-banner"
                    className="mb-5 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5 animate-in fade-in"
                  >
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                {/* Form */}
                <form onSubmit={handleSignupSubmit} className="space-y-4">
                  {/* Full Name */}
                  <div>
                    <label
                      htmlFor="signup-name-input"
                      className="block text-xs font-semibold text-slate-300 mb-1.5"
                    >
                      Full Name
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        id="signup-name-input"
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="Ranjith Kumar"
                        className={`w-full pl-9 pr-3 py-2.5 bg-slate-950 border ${
                          fieldErrors.fullName ? 'border-rose-500/80 focus:border-rose-400' : 'border-slate-800 focus:border-cyan-500'
                        } rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-hidden transition`}
                      />
                    </div>
                    {fieldErrors.fullName && (
                      <p id="signup-name-error" className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {fieldErrors.fullName}
                      </p>
                    )}
                  </div>

                  {/* Email */}
                  <div>
                    <label
                      htmlFor="signup-email-input"
                      className="block text-xs font-semibold text-slate-300 mb-1.5"
                    >
                      Corporate / Developer Email
                    </label>
                    <div className="relative">
                      <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        id="signup-email-input"
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="ranjith@enterprise.io"
                        className={`w-full pl-9 pr-3 py-2.5 bg-slate-950 border ${
                          fieldErrors.email ? 'border-rose-500/80 focus:border-rose-400' : 'border-slate-800 focus:border-cyan-500'
                        } rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-hidden transition`}
                      />
                    </div>
                    {fieldErrors.email && (
                      <p id="signup-email-error" className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {fieldErrors.email}
                      </p>
                    )}
                  </div>

                  {/* Password */}
                  <div>
                    <label
                      htmlFor="signup-password-input"
                      className="block text-xs font-semibold text-slate-300 mb-1.5"
                    >
                      Password (min 8 chars)
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        id="signup-password-input"
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className={`w-full pl-9 pr-10 py-2.5 bg-slate-950 border ${
                          fieldErrors.password ? 'border-rose-500/80 focus:border-rose-400' : 'border-slate-800 focus:border-cyan-500'
                        } rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-hidden transition font-mono`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="p-1 text-slate-400 hover:text-slate-200 absolute right-2.5 top-1/2 -translate-y-1/2"
                      >
                        {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    {fieldErrors.password && (
                      <p id="signup-password-error" className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {fieldErrors.password}
                      </p>
                    )}
                  </div>

                  {/* Confirm Password */}
                  <div>
                    <label
                      htmlFor="signup-confirm-password-input"
                      className="block text-xs font-semibold text-slate-300 mb-1.5"
                    >
                      Confirm Password
                    </label>
                    <div className="relative">
                      <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        id="signup-confirm-password-input"
                        type={showConfirmPassword ? 'text' : 'password'}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="••••••••••••"
                        className={`w-full pl-9 pr-10 py-2.5 bg-slate-950 border ${
                          fieldErrors.confirmPassword ? 'border-rose-500/80 focus:border-rose-400' : 'border-slate-800 focus:border-cyan-500'
                        } rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-hidden transition font-mono`}
                      />
                      <button
                        type="button"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        className="p-1 text-slate-400 hover:text-slate-200 absolute right-2.5 top-1/2 -translate-y-1/2"
                      >
                        {showConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    {fieldErrors.confirmPassword && (
                      <p id="signup-confirm-password-error" className="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {fieldErrors.confirmPassword}
                      </p>
                    )}
                  </div>

                  {/* Submit Button */}
                  <button
                    id="signup-submit-btn"
                    type="submit"
                    disabled={isLoading}
                    className="w-full mt-2 py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-950/50 flex items-center justify-center gap-2 cursor-pointer transition disabled:opacity-50"
                  >
                    {isLoading ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Creating Enterprise Account...</span>
                      </>
                    ) : (
                      <>
                        <span>Create Account</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </form>

                {/* Footer Switcher */}
                <div className="mt-6 text-center text-xs text-slate-400">
                  Already have an account?{' '}
                  <button
                    id="switch-to-login-btn"
                    type="button"
                    onClick={() => switchMode('login')}
                    className="text-cyan-400 hover:text-cyan-300 font-semibold transition"
                  >
                    Login
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ============================================================ */}
          {/* VIEW 4: FORGOT PASSWORD */}
          {/* ============================================================ */}
          {viewMode === 'forgot' && (
            <div className="max-w-md mx-auto">
              <div
                id="forgot-card"
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-md"
              >
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-12 h-12 rounded-xl bg-cyan-950/80 border border-cyan-700/40 text-cyan-400 mb-3 shadow-md">
                    <Mail className="w-6 h-6" />
                  </div>
                  <h2 className="text-xl font-bold text-slate-100">Reset Password</h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Enter your registered email to receive secure recovery steps
                  </p>
                </div>

                {successMessage ? (
                  <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs space-y-4">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{successMessage}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => switchMode('login')}
                      className="w-full py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs rounded-lg transition"
                    >
                      Return to Login
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
                    <div>
                      <label
                        htmlFor="forgot-email-input"
                        className="block text-xs font-semibold text-slate-300 mb-1.5"
                      >
                        Registered Email
                      </label>
                      <div className="relative">
                        <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                        <input
                          id="forgot-email-input"
                          type="email"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="ranjith@enterprise.io"
                          className={`w-full pl-9 pr-3 py-2.5 bg-slate-950 border ${
                            fieldErrors.email ? 'border-rose-500/80 focus:border-rose-400' : 'border-slate-800 focus:border-cyan-500'
                          } rounded-xl text-xs text-slate-100 placeholder:text-slate-500 focus:outline-hidden transition`}
                        />
                      </div>
                      {fieldErrors.email && (
                        <p className="text-[11px] text-rose-400 mt-1">{fieldErrors.email}</p>
                      )}
                    </div>

                    <button
                      id="forgot-submit-btn"
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-950/50 flex items-center justify-center gap-2 cursor-pointer transition disabled:opacity-50"
                    >
                      {isLoading ? (
                        <>
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>Dispatching Instructions...</span>
                        </>
                      ) : (
                        <span>Send Reset Instructions</span>
                      )}
                    </button>

                    <div className="text-center pt-2">
                      <button
                        type="button"
                        onClick={() => switchMode('login')}
                        className="text-xs text-slate-400 hover:text-slate-200 transition"
                      >
                        ← Back to Login
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Transparent Google OAuth Modal (Compliant with requirement #4) */}
      {showGoogleConfigModal && (
        <div
          id="google-config-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs animate-in fade-in"
        >
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center">
                <svg className="w-5 h-5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-100">Google Authentication Setup</h3>
                <p className="text-[11px] text-slate-400">Standard Google Cloud OAuth 2.0</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed mb-4">
              To connect live corporate Google OAuth, provide your Client ID in <code className="px-1.5 py-0.5 rounded bg-slate-950 text-cyan-400 font-mono text-[11px]">.env.example</code> under <code className="text-cyan-400 font-mono text-[11px]">VITE_GOOGLE_CLIENT_ID</code>.
            </p>

            <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-[11px] text-slate-400 mb-5 space-y-1">
              <div className="text-slate-500"># Google Cloud Console &gt; Credentials</div>
              <div className="text-cyan-400">VITE_GOOGLE_CLIENT_ID="&lt;YOUR_CLIENT_ID&gt;.apps.googleusercontent.com"</div>
            </div>

            <div className="space-y-2">
              <button
                id="google-demo-continue-btn"
                type="button"
                onClick={() => {
                  setShowGoogleConfigModal(false);
                  loginWithGoogle({
                    name: 'Ranjith Kumar',
                    email: 'ranjith.dev@enterprise.io',
                  });
                }}
                className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition cursor-pointer flex items-center justify-center gap-2"
              >
                <span>Continue as Verified Google Identity (Ranjith Kumar)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                type="button"
                onClick={() => setShowGoogleConfigModal(false)}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="relative z-10 w-full max-w-7xl mx-auto px-6 py-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-cyan-500" />
          <span>Secret Leak Detector Enterprise Guard</span>
        </div>
        <div className="flex items-center gap-4 text-[11px]">
          <span>Shannon Entropy Analysis</span>
          <span>•</span>
          <span>Zero-Trust Masking</span>
          <span>•</span>
          <span>SHA-256 Fingerprinting</span>
        </div>
      </footer>
    </div>
  );
};

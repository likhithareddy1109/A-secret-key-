import React, { useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  FolderGit2,
  GitBranch,
  Lock,
  Play,
  Plus,
  RotateCcw,
  Search,
  Settings,
  Shield,
  ShieldAlert,
  Trash2,
  Unlock,
  X,
} from 'lucide-react';
import { ConfirmationModal } from '../components/ConfirmationModal';
import { useData } from '../context/DataContext';
import { Repository } from '../types';

interface RepositoriesPageProps {
  onNavigateFindingsForRepo?: (repoName: string) => void;
  onNavigateScans?: () => void;
}

export const RepositoriesPage: React.FC<RepositoriesPageProps> = ({
  onNavigateFindingsForRepo,
  onNavigateScans,
}) => {
  const {
    repositories,
    addRepository,
    updateRepository,
    removeRepository,
    triggerScan,
    canManageSettings,
    canTriggerScan,
  } = useData();

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [visibilityFilter, setVisibilityFilter] = useState<string>('all');
  const [languageFilter, setLanguageFilter] = useState<string>('all');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingRepo, setEditingRepo] = useState<Repository | null>(null);
  const [repoToRemove, setRepoToRemove] = useState<Repository | null>(null);

  // Scanning state
  const [activeScanningRepoId, setActiveScanningRepoId] = useState<string | null>(null);

  // Add Form state
  const [newName, setNewName] = useState('');
  const [newDefaultBranch, setNewDefaultBranch] = useState('main');
  const [newLanguage, setNewLanguage] = useState('TypeScript');
  const [newVisibility, setNewVisibility] = useState<'Private' | 'Public'>('Private');
  const [newAutoScan, setNewAutoScan] = useState(true);
  const [formError, setFormError] = useState('');

  // Edit Form state
  const [editDefaultBranch, setEditDefaultBranch] = useState('main');
  const [editLanguage, setEditLanguage] = useState('TypeScript');
  const [editVisibility, setEditVisibility] = useState<'Private' | 'Public'>('Private');
  const [editAutoScan, setEditAutoScan] = useState(true);

  const filteredRepos = repositories.filter((repo) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      if (!repo.name.toLowerCase().includes(q) && !repo.language.toLowerCase().includes(q)) {
        return false;
      }
    }
    if (visibilityFilter !== 'all' && repo.visibility !== visibilityFilter) {
      return false;
    }
    if (languageFilter !== 'all' && repo.language !== languageFilter) {
      return false;
    }
    return true;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) {
      setFormError('Repository name is required.');
      return;
    }
    const cleanName = newName.trim().toLowerCase().replace(/\s+/g, '-');
    if (repositories.some((r) => r.name.toLowerCase() === cleanName)) {
      setFormError('A repository with this name is already enrolled.');
      return;
    }

    addRepository({
      name: cleanName,
      defaultBranch: newDefaultBranch.trim() || 'main',
      language: newLanguage,
      visibility: newVisibility,
      autoScan: newAutoScan,
    });

    setNewName('');
    setNewDefaultBranch('main');
    setNewLanguage('TypeScript');
    setNewVisibility('Private');
    setNewAutoScan(true);
    setFormError('');
    setIsAddModalOpen(false);
  };

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRepo) return;

    updateRepository(editingRepo.id, {
      defaultBranch: editDefaultBranch,
      language: editLanguage,
      visibility: editVisibility,
      autoScan: editAutoScan,
    });

    setEditingRepo(null);
  };

  const handleRunScanNow = async (repo: Repository) => {
    setActiveScanningRepoId(repo.id);
    try {
      await triggerScan(repo.id, 'Manual on-demand scan');
    } finally {
      setActiveScanningRepoId(null);
    }
  };

  return (
    <div id="repositories-page" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <FolderGit2 className="w-5 h-5 text-cyan-400" />
            Monitored Repositories
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Enrolled source code repositories under continuous secret inspection and git hook monitoring.
          </p>
        </div>

        <button
          id="add-repository-btn"
          onClick={() => {
            setFormError('');
            setIsAddModalOpen(true);
          }}
          disabled={!canManageSettings}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-cyan-600 hover:bg-cyan-500 text-white transition shadow-sm shadow-cyan-950 disabled:opacity-40 disabled:cursor-not-allowed"
          title={!canManageSettings ? 'Only Owner or Admin can enroll new repositories' : 'Add repository'}
        >
          <Plus className="w-4 h-4" />
          Enroll Repository
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="repo-search-input"
            type="text"
            placeholder="Search by repository name or language..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 placeholder-slate-500 focus:outline-hidden focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <select
            id="repo-visibility-filter"
            value={visibilityFilter}
            onChange={(e) => setVisibilityFilter(e.target.value)}
            className="py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500 flex-1 md:flex-none"
          >
            <option value="all">All Visibilities</option>
            <option value="Private">Private</option>
            <option value="Public">Public</option>
          </select>

          <select
            id="repo-language-filter"
            value={languageFilter}
            onChange={(e) => setLanguageFilter(e.target.value)}
            className="py-2 px-3 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500 flex-1 md:flex-none"
          >
            <option value="all">All Languages</option>
            <option value="TypeScript">TypeScript</option>
            <option value="JavaScript">JavaScript</option>
            <option value="Python">Python</option>
            <option value="Go">Go</option>
            <option value="Java">Java</option>
            <option value="Rust">Rust</option>
          </select>
        </div>
      </div>

      {/* Repositories Cards / Table */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredRepos.map((repo) => {
          const isScanningThis = activeScanningRepoId === repo.id;

          return (
            <div
              key={repo.id}
              id={`repo-card-${repo.id}`}
              className="bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-2xl p-5 shadow-lg flex flex-col justify-between space-y-4 transition"
            >
              {/* Card Header */}
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="space-y-1">
                    <h3 className="font-bold text-slate-100 font-mono text-sm flex items-center gap-1.5">
                      <FolderGit2 className="w-4 h-4 text-cyan-400 shrink-0" />
                      <span className="truncate">{repo.name}</span>
                    </h3>
                    <div className="flex items-center gap-2 text-[11px] text-slate-400">
                      <span className="flex items-center gap-1 font-mono">
                        <GitBranch className="w-3 h-3 text-slate-500" />
                        {repo.defaultBranch}
                      </span>
                      <span>•</span>
                      <span>{repo.language}</span>
                    </div>
                  </div>

                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold border ${
                      repo.visibility === 'Private'
                        ? 'bg-slate-950 text-slate-300 border-slate-700'
                        : 'bg-blue-950 text-blue-300 border-blue-700'
                    }`}
                  >
                    {repo.visibility === 'Private' ? (
                      <Lock className="w-2.5 h-2.5 text-slate-400" />
                    ) : (
                      <Unlock className="w-2.5 h-2.5 text-blue-400" />
                    )}
                    {repo.visibility}
                  </span>
                </div>

                {/* Metrics row */}
                <div className="grid grid-cols-3 gap-2 mt-4 pt-3 border-t border-slate-800/80 text-center">
                  <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/60">
                    <span className="text-[10px] text-slate-400 block">Health</span>
                    <span
                      className={`text-sm font-bold font-mono ${
                        repo.healthScore >= 80
                          ? 'text-emerald-400'
                          : repo.healthScore >= 60
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {repo.healthScore}%
                    </span>
                  </div>

                  <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/60">
                    <span className="text-[10px] text-slate-400 block">Open Leaks</span>
                    <span
                      className={`text-sm font-bold font-mono ${
                        repo.openFindings > 0 ? 'text-rose-400' : 'text-slate-300'
                      }`}
                    >
                      {repo.openFindings}
                    </span>
                  </div>

                  <div className="bg-slate-950/60 p-2 rounded-xl border border-slate-800/60">
                    <span className="text-[10px] text-slate-400 block">Scans</span>
                    <span className="text-sm font-bold font-mono text-cyan-400">
                      {repo.totalScans}
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-400 mt-3">
                  Last scanned: <span className="text-slate-200 font-mono">{repo.lastScanDate}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  id={`scan-repo-btn-${repo.id}`}
                  onClick={() => handleRunScanNow(repo)}
                  disabled={!canTriggerScan || isScanningThis}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 transition disabled:opacity-40"
                  title="Run on-demand deep scan"
                >
                  {isScanningThis ? (
                    <>
                      <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                      Scanning...
                    </>
                  ) : (
                    <>
                      <Play className="w-3 h-3 fill-current" />
                      Run Scan
                    </>
                  )}
                </button>

                <div className="flex items-center gap-1">
                  {onNavigateFindingsForRepo && (
                    <button
                      onClick={() => onNavigateFindingsForRepo(repo.name)}
                      className="px-2 py-1 text-xs text-slate-300 hover:text-cyan-300 hover:bg-slate-800 rounded transition"
                      title="View all findings in this repository"
                    >
                      Findings
                    </button>
                  )}

                  <button
                    id={`edit-repo-btn-${repo.id}`}
                    onClick={() => {
                      setEditingRepo(repo);
                      setEditDefaultBranch(repo.defaultBranch);
                      setEditLanguage(repo.language);
                      setEditVisibility(repo.visibility);
                      setEditAutoScan(repo.autoScan);
                    }}
                    disabled={!canManageSettings}
                    className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded transition disabled:opacity-30"
                    title="Edit repository settings"
                  >
                    <Settings className="w-3.5 h-3.5" />
                  </button>

                  <button
                    id={`delete-repo-btn-${repo.id}`}
                    onClick={() => setRepoToRemove(repo)}
                    disabled={!canManageSettings}
                    className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-rose-950/40 rounded transition disabled:opacity-30"
                    title="Remove repository from monitoring"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Repository Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <FolderGit2 className="w-4 h-4 text-cyan-400" />
                Enroll New Repository
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="mb-4 text-xs text-rose-400 bg-rose-950/30 border border-rose-900/40 p-2.5 rounded-lg">
                {formError}
              </div>
            )}

            <form onSubmit={handleAddSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Repository Name (e.g. org/repo)
                </label>
                <input
                  id="new-repo-name-input"
                  type="text"
                  placeholder="e.g. payment-service-api"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500 font-mono"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Default Branch</label>
                  <input
                    id="new-repo-branch-input"
                    type="text"
                    value={newDefaultBranch}
                    onChange={(e) => setNewDefaultBranch(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Primary Language</label>
                  <select
                    id="new-repo-lang-select"
                    value={newLanguage}
                    onChange={(e) => setNewLanguage(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="TypeScript">TypeScript</option>
                    <option value="JavaScript">JavaScript</option>
                    <option value="Python">Python</option>
                    <option value="Go">Go</option>
                    <option value="Java">Java</option>
                    <option value="Rust">Rust</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Visibility</label>
                  <select
                    id="new-repo-vis-select"
                    value={newVisibility}
                    onChange={(e) => setNewVisibility(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Private">Private</option>
                    <option value="Public">Public</option>
                  </select>
                </div>

                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newAutoScan}
                      onChange={(e) => setNewAutoScan(e.target.checked)}
                      className="w-4 h-4 accent-cyan-500 rounded"
                    />
                    <span className="text-[11px] text-slate-300">Continuous Auto-Scan</span>
                  </label>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 font-medium"
                >
                  Cancel
                </button>
                <button
                  id="confirm-add-repo-btn"
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold"
                >
                  Enroll Repository
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit Repository Modal */}
      {editingRepo && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-md w-full text-slate-100 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-100">
                Edit Settings: {editingRepo.name}
              </h3>
              <button
                onClick={() => setEditingRepo(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">Default Branch</label>
                <input
                  id="edit-repo-branch-input"
                  type="text"
                  value={editDefaultBranch}
                  onChange={(e) => setEditDefaultBranch(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Language</label>
                  <select
                    id="edit-repo-lang-select"
                    value={editLanguage}
                    onChange={(e) => setEditLanguage(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="TypeScript">TypeScript</option>
                    <option value="JavaScript">JavaScript</option>
                    <option value="Python">Python</option>
                    <option value="Go">Go</option>
                    <option value="Java">Java</option>
                    <option value="Rust">Rust</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold mb-1">Visibility</label>
                  <select
                    id="edit-repo-vis-select"
                    value={editVisibility}
                    onChange={(e) => setEditVisibility(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                  >
                    <option value="Private">Private</option>
                    <option value="Public">Public</option>
                  </select>
                </div>
              </div>

              <label className="flex items-center gap-2 p-2 rounded-lg bg-slate-950 border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={editAutoScan}
                  onChange={(e) => setEditAutoScan(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
                <span className="text-slate-300">Continuous Auto-Scan Enabled</span>
              </label>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingRepo(null)}
                  className="px-3 py-2 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  id="save-repo-edit-btn"
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold"
                >
                  Save Settings
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Removal Confirmation */}
      {repoToRemove && (
        <ConfirmationModal
          isOpen={true}
          title={`Un-enroll ${repoToRemove.name}?`}
          message={`Are you sure you want to stop monitoring ${repoToRemove.name}? Future commits will not be scanned, but past finding history will remain archived.`}
          confirmLabel="Remove Repository"
          confirmVariant="danger"
          onConfirm={() => {
            removeRepository(repoToRemove.id);
            setRepoToRemove(null);
          }}
          onCancel={() => setRepoToRemove(null)}
        />
      )}
    </div>
  );
};

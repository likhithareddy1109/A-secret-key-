import React, { useState } from 'react';
import {
  Activity,
  AlertOctagon,
  AlertTriangle,
  Award,
  Bell,
  Check,
  CheckCheck,
  CheckCircle2,
  FolderGit2,
  Info,
  ShieldAlert,
  Trash2,
  UserPlus,
} from 'lucide-react';
import { useData } from '../context/DataContext';
import { NotificationItem, NotificationSeverity, NotificationType } from '../types';

interface NotificationsPageProps {
  onNavigateFinding?: (findingId: string) => void;
}

export const NotificationsPage: React.FC<NotificationsPageProps> = ({ onNavigateFinding }) => {
  const {
    notifications,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    deleteNotification,
    clearAllNotifications,
    unreadNotificationsCount,
  } = useData();

  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [readFilter, setReadFilter] = useState<string>('all'); // 'all' | 'unread' | 'read'

  const filteredNotifications = notifications.filter((notif) => {
    if (typeFilter !== 'all' && notif.type !== typeFilter) {
      return false;
    }
    if (readFilter === 'unread' && notif.read) {
      return false;
    }
    if (readFilter === 'read' && !notif.read) {
      return false;
    }
    return true;
  });

  const getSeverityIcon = (severity: NotificationSeverity, type: NotificationType) => {
    switch (type) {
      case 'finding_critical':
        return <AlertOctagon className="w-4 h-4 text-rose-400" />;
      case 'finding_high':
        return <ShieldAlert className="w-4 h-4 text-amber-400" />;
      case 'finding_resolved':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'scan_completed':
        return <Activity className="w-4 h-4 text-cyan-400" />;
      case 'scan_failed':
        return <AlertTriangle className="w-4 h-4 text-rose-400" />;
      case 'repo_added':
        return <FolderGit2 className="w-4 h-4 text-blue-400" />;
      case 'team_member_added':
        return <UserPlus className="w-4 h-4 text-purple-400" />;
      case 'compliance_changed':
        return <Award className="w-4 h-4 text-emerald-400" />;
      default:
        return <Info className="w-4 h-4 text-slate-400" />;
    }
  };

  const getSeverityBadge = (severity: NotificationSeverity) => {
    switch (severity) {
      case 'critical':
        return 'bg-rose-500/15 text-rose-300 border-rose-500/30';
      case 'high':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      case 'warning':
        return 'bg-amber-500/15 text-amber-300 border-amber-500/30';
      case 'success':
        return 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30';
      case 'info':
      default:
        return 'bg-blue-500/15 text-blue-300 border-blue-500/30';
    }
  };

  return (
    <div id="notifications-page" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Bell className="w-5 h-5 text-cyan-400" />
            Security Alerts & Notifications
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Automated event feed for leak alerts, pipeline scan verdicts, team activity, and compliance score updates.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {unreadNotificationsCount > 0 && (
            <button
              id="mark-all-read-btn"
              onClick={markAllNotificationsAsRead}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
            >
              <CheckCheck className="w-3.5 h-3.5 text-cyan-400" />
              Mark All as Read ({unreadNotificationsCount})
            </button>
          )}

          {notifications.length > 0 && (
            <button
              id="clear-all-notif-btn"
              onClick={clearAllNotifications}
              className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-400 border border-slate-800 text-xs transition"
              title="Clear all notifications"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            id="notif-type-filter"
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500 w-full sm:w-auto"
          >
            <option value="all">All Notification Types</option>
            <option value="finding_critical">Critical Findings</option>
            <option value="finding_high">High Risk Findings</option>
            <option value="finding_resolved">Findings Resolved</option>
            <option value="scan_completed">Scan Completed</option>
            <option value="scan_failed">Scan Failed</option>
            <option value="repo_added">Repository Added</option>
            <option value="team_member_added">Team Member Added</option>
            <option value="compliance_changed">Compliance Changed</option>
          </select>

          <select
            id="notif-read-filter"
            value={readFilter}
            onChange={(e) => setReadFilter(e.target.value)}
            className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-200 focus:outline-hidden focus:border-cyan-500"
          >
            <option value="all">All (Read & Unread)</option>
            <option value="unread">Unread Only</option>
            <option value="read">Read Only</option>
          </select>
        </div>

        <div className="text-xs text-slate-400">
          Showing <strong className="text-slate-200">{filteredNotifications.length}</strong> of{' '}
          <strong className="text-slate-200">{notifications.length}</strong> total alerts
        </div>
      </div>

      {/* Notifications List */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl divide-y divide-slate-800 overflow-hidden shadow-lg">
        {filteredNotifications.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <Bell className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <p className="font-semibold text-slate-300">No notifications found</p>
            <p className="text-xs text-slate-400 mt-1">You're all caught up on security alerts and scans.</p>
          </div>
        ) : (
          filteredNotifications.map((notif) => (
            <div
              key={notif.id}
              id={`notification-item-${notif.id}`}
              className={`p-4 transition-colors flex items-start justify-between gap-4 ${
                notif.read ? 'bg-slate-900/50 hover:bg-slate-800/40' : 'bg-slate-950/80 hover:bg-slate-900/90'
              }`}
            >
              <div className="flex items-start gap-3 flex-1">
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 shrink-0 mt-0.5">
                  {getSeverityIcon(notif.severity, notif.type)}
                </div>

                <div className="space-y-1 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-xs font-bold text-slate-100">{notif.title}</h4>
                    <span
                      className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded-md border ${getSeverityBadge(
                        notif.severity
                      )}`}
                    >
                      {notif.severity}
                    </span>
                    {!notif.read && (
                      <span className="w-2 h-2 rounded-full bg-cyan-400 inline-block animate-pulse" />
                    )}
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">{notif.message}</p>

                  <div className="flex items-center gap-3 text-[11px] text-slate-400 pt-0.5">
                    <span className="font-mono">{notif.timestamp}</span>
                    {notif.targetId && (
                      <span className="font-mono text-cyan-400/90 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800 text-[10px]">
                        Target: {notif.targetId}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-1 shrink-0">
                {!notif.read && (
                  <button
                    id={`mark-read-btn-${notif.id}`}
                    onClick={() => markNotificationAsRead(notif.id)}
                    className="p-1.5 text-slate-400 hover:text-cyan-300 rounded hover:bg-slate-800 transition"
                    title="Mark as Read"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                )}

                <button
                  id={`delete-notif-btn-${notif.id}`}
                  onClick={() => deleteNotification(notif.id)}
                  className="p-1.5 text-slate-400 hover:text-rose-400 rounded hover:bg-rose-950/40 transition"
                  title="Delete Notification"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

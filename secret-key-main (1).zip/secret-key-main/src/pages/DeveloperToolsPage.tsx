import React, { useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Check,
  CheckCircle2,
  Code2,
  Copy,
  FileCode,
  Fingerprint,
  GitBranch,
  GitCommit,
  Info,
  Play,
  RotateCcw,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Terminal,
} from 'lucide-react';
import { RiskBadge } from '../components/RiskBadge';
import { useData } from '../context/DataContext';
import {
  PRECOMMIT_HOOK_SCRIPT,
  SAFE_DEMO_CODE_SNIPPET,
  ScanMatch,
  scanCodeForSecrets,
} from '../services/scannerEngine';

export const DeveloperToolsPage: React.FC = () => {
  const { settings, createFinding, repositories } = useData();

  // Scanner UI states
  const [codeContent, setCodeContent] = useState<string>(SAFE_DEMO_CODE_SNIPPET);
  const [scanResults, setScanResults] = useState<ScanMatch[] | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [copiedHook, setCopiedHook] = useState(false);
  const [importedFindingIds, setImportedFindingIds] = useState<Set<number>>(new Set());

  // Run scanner
  const handleScanCode = () => {
    if (!codeContent.trim()) {
      setScanResults([]);
      return;
    }

    setIsScanning(true);
    setTimeout(() => {
      const results = scanCodeForSecrets(codeContent, {
        entropyEnabled: settings.scanner.entropyDetection,
        confidenceThreshold: settings.scanner.confidenceThreshold,
        ignoreTestDemo: settings.scanner.ignoreTestFiles,
      });
      setScanResults(results);
      setIsScanning(false);
      setImportedFindingIds(new Set());
    }, 350);
  };

  const handleClear = () => {
    setCodeContent('');
    setScanResults(null);
    setImportedFindingIds(new Set());
  };

  const handleLoadDemo = () => {
    setCodeContent(SAFE_DEMO_CODE_SNIPPET);
    setScanResults(null);
    setImportedFindingIds(new Set());
  };

  const handleCopyHook = () => {
    navigator.clipboard.writeText(PRECOMMIT_HOOK_SCRIPT);
    setCopiedHook(true);
    setTimeout(() => setCopiedHook(false), 2500);
  };

  // Convert a scanner result into an active finding in the database
  const handleSaveToDatabase = (match: ScanMatch, index: number) => {
    const targetRepo = repositories[0] || { id: 'repo-1', name: 'payment-core-api' };
    const now = new Date();
    const dateStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    createFinding({
      repoId: targetRepo.id,
      repoName: targetRepo.name,
      secretType: match.secretType,
      fileName: 'developer-workspace/test-snippet.ts',
      lineNumber: match.lineNumber,
      riskLevel: match.riskLevel,
      confidence: match.confidence,
      detectionMethod: match.detectionMethod,
      status: 'Open',
      detectedDate: dateStr,
      maskedPreview: match.maskedValue,
      fingerprint: match.fingerprint,
      author: 'local-developer (Hook)',
      commitHash: 'local_head',
      remediationAdvice: match.explanation,
    });

    setImportedFindingIds((prev) => new Set(prev).add(index));
  };

  return (
    <div id="developer-tools-page" className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
          <Terminal className="w-5 h-5 text-cyan-400" />
          Developer Tools & Pre-Commit Scanner
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Shift-left security integration: prevent credentials from ever entering version control history.
        </p>
      </div>

      {/* Workflow Diagram & Architecture */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <h3 className="text-sm font-bold text-slate-100 mb-2 flex items-center gap-2">
          <GitBranch className="w-4 h-4 text-cyan-400" />
          Pre-Commit Prevention Architecture
        </h3>
        <p className="text-xs text-slate-400 mb-6">
          How local workstation scans stop accidental commits before code leaves your machine:
        </p>

        {/* Visual Pipeline Flow */}
        <div className="grid grid-cols-2 md:grid-cols-7 gap-2 items-center text-center">
          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl">
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 mx-auto flex items-center justify-center font-bold text-xs mb-1.5">
              1
            </div>
            <div className="text-xs font-semibold text-slate-200">Developer</div>
            <div className="text-[10px] text-slate-400">Writes code</div>
          </div>

          <div className="hidden md:flex justify-center text-slate-600">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl">
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 mx-auto flex items-center justify-center font-bold text-xs mb-1.5">
              2
            </div>
            <div className="text-xs font-semibold text-slate-200">Git Commit</div>
            <div className="text-[10px] text-slate-400">Stages changes</div>
          </div>

          <div className="hidden md:flex justify-center text-slate-600">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="bg-slate-950/80 border border-cyan-500/40 p-3 rounded-xl shadow-xs shadow-cyan-950">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/15 text-cyan-400 mx-auto flex items-center justify-center font-bold text-xs mb-1.5">
              3
            </div>
            <div className="text-xs font-semibold text-cyan-300">Secret Scanner</div>
            <div className="text-[10px] text-cyan-400/80">Analyzes diffs</div>
          </div>

          <div className="hidden md:flex justify-center text-slate-600">
            <ArrowRight className="w-4 h-4" />
          </div>

          <div className="bg-slate-950/80 border border-emerald-500/30 p-3 rounded-xl">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 mx-auto flex items-center justify-center font-bold text-xs mb-1.5">
              4
            </div>
            <div className="text-xs font-semibold text-emerald-300">Allow / Block</div>
            <div className="text-[10px] text-slate-400">Zero raw leaks</div>
          </div>
        </div>

        {/* Disclaimer Card */}
        <div className="mt-6 bg-slate-950 border border-slate-800 rounded-xl p-4 flex items-start gap-3 text-xs text-slate-300">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-semibold text-slate-100">Local Installation Policy:</span>
            <p className="text-slate-400 leading-relaxed">
              Browser security sandboxes strictly prevent web applications from modifying your local file system or installing Git hooks automatically. Follow the local configuration guide below to enable automated pre-commit scanning on your developer workstation.
            </p>
          </div>
        </div>
      </div>

      {/* Pre-Commit Hook Code Snippet & Instructions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <FileCode className="w-4 h-4 text-cyan-400" />
              Copyable Pre-Commit Hook Script (.git/hooks/pre-commit)
            </h3>
            <p className="text-xs text-slate-400">
              POSIX-compliant bash script compatible with macOS, Linux, and Windows Git Bash
            </p>
          </div>

          <button
            id="copy-precommit-hook-btn"
            onClick={handleCopyHook}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition"
          >
            {copiedHook ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
            {copiedHook ? 'Hook Copied!' : 'Copy Hook'}
          </button>
        </div>

        {/* Installation Instructions */}
        <div className="mb-4 bg-slate-950/70 border border-slate-800 rounded-xl p-3.5 text-xs text-slate-300 space-y-1.5">
          <p className="font-semibold text-cyan-400">Quick 2-Step Local Installation:</p>
          <div className="font-mono text-[11px] text-slate-400 space-y-1 pl-2">
            <div>
              1. Save to repo hook: <span className="text-slate-200">cat &lt;&lt; 'EOF' &gt; .git/hooks/pre-commit</span>
            </div>
            <div>
              2. Make executable: <span className="text-slate-200">chmod +x .git/hooks/pre-commit</span>
            </div>
          </div>
        </div>

        {/* Code Box */}
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-[11px] text-slate-300 max-h-56 overflow-y-auto leading-relaxed">
          <pre>{PRECOMMIT_HOOK_SCRIPT}</pre>
        </div>
      </div>

      {/* Interactive Demo Scanner */}
      <div id="interactive-demo-scanner" className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              Live Interactive Secret Scanner
            </h3>
            <p className="text-xs text-slate-400">
              Paste code below or test with synthetic credentials (regex matching + Shannon entropy calculation).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="load-demo-code-btn"
              onClick={handleLoadDemo}
              className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-slate-100 border border-slate-700 transition"
              title="Load safe synthetic demo credentials"
            >
              Test Scanner (Safe Demo)
            </button>
            <button
              id="clear-code-btn"
              onClick={handleClear}
              className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 transition"
            >
              Clear
            </button>
          </div>
        </div>

        {/* Textarea for code */}
        <div className="relative">
          <textarea
            id="scanner-code-input"
            rows={10}
            value={codeContent}
            onChange={(e) => setCodeContent(e.target.value)}
            placeholder="Paste code or configuration files to scan for credential leaks..."
            className="w-full font-mono text-xs text-slate-200 bg-slate-950 border border-slate-800 rounded-xl p-4 focus:outline-hidden focus:border-cyan-500 leading-relaxed resize-y"
          />
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-2 text-xs text-slate-400">
            <span className="font-mono">
              Entropy Engine:{' '}
              <strong className={settings.scanner.entropyDetection ? 'text-emerald-400' : 'text-slate-500'}>
                {settings.scanner.entropyDetection ? 'Enabled' : 'Disabled'}
              </strong>
            </span>
            <span>•</span>
            <span className="font-mono">
              Threshold: <strong className="text-cyan-400">{settings.scanner.confidenceThreshold}%</strong>
            </span>
          </div>

          <button
            id="run-code-scan-btn"
            onClick={handleScanCode}
            disabled={isScanning}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition shadow-md shadow-cyan-950 disabled:opacity-50"
          >
            {isScanning ? (
              <>
                <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                Scanning Code...
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                Scan Code
              </>
            )}
          </button>
        </div>

        {/* Scan Results Section */}
        {scanResults !== null && (
          <div
            id="scan-results-container"
            className="mt-6 pt-6 border-t border-slate-800 animate-in fade-in duration-200"
          >
            <div className="flex items-center justify-between mb-4">
              <h4 className="text-sm font-bold text-slate-100 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-cyan-400" />
                View Scan Result ({scanResults.length} pattern{scanResults.length === 1 ? '' : 's'} detected)
              </h4>
              <span className="text-xs font-mono text-slate-400">
                Safe preview: raw secrets masked immediately
              </span>
            </div>

            {scanResults.length === 0 ? (
              <div className="bg-emerald-950/20 border border-emerald-900/30 rounded-xl p-5 text-center">
                <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto mb-1.5" />
                <p className="text-xs font-semibold text-emerald-300">Clean Scan: No Secret Leaks Detected</p>
                <p className="text-[11px] text-slate-400 mt-1">
                  The analyzed code snippet does not contain known credential signatures or high-entropy tokens.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {scanResults.map((match, idx) => {
                  const isImported = importedFindingIds.has(idx);

                  return (
                    <div
                      key={idx}
                      id={`scan-result-item-${idx}`}
                      className="bg-slate-950 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2.5 flex-wrap">
                          <RiskBadge level={match.riskLevel} />
                          <span className="font-semibold text-slate-200 text-xs">{match.secretType}</span>
                          <span className="text-slate-400 font-mono text-[11px]">
                            Line {match.lineNumber}:{match.columnNumber}
                          </span>
                          <span className="text-[11px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                            {match.detectionMethod}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-emerald-400 font-mono text-xs font-bold">
                            {match.confidence}% Confidence
                          </span>
                          <button
                            id={`import-finding-btn-${idx}`}
                            onClick={() => handleSaveToDatabase(match, idx)}
                            disabled={isImported}
                            className={`px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                              isImported
                                ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/40'
                                : 'bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30'
                            }`}
                            title="Register this detected leak into central findings database"
                          >
                            {isImported ? 'Registered in DB' : '+ Add to Findings'}
                          </button>
                        </div>
                      </div>

                      {/* Masked Secret Output */}
                      <div className="bg-slate-900 border border-slate-800 rounded-lg p-2.5 font-mono text-xs text-slate-300 mb-2 flex items-center justify-between">
                        <div>
                          <span className="text-slate-500 mr-2">Masked:</span>
                          <span className="text-rose-400 font-semibold">{match.maskedValue}</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-mono">
                          Fingerprint: {match.fingerprint.slice(0, 14)}...
                        </span>
                      </div>

                      {/* Snippet */}
                      <div className="text-[11px] font-mono text-slate-400 bg-slate-900/40 px-3 py-1.5 rounded border border-slate-800/60 truncate">
                        {match.lineSnippet}
                      </div>

                      <p className="text-[11px] text-slate-400 mt-2">{match.explanation}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

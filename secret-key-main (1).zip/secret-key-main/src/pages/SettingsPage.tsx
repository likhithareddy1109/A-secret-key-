import React, { useState } from 'react';
import {
  AlertTriangle,
  Bell,
  Check,
  FolderGit2,
  Lock,
  Moon,
  Save,
  Scan,
  Shield,
  Sun,
  User,
} from 'lucide-react';
import { useData } from '../context/DataContext';

export const SettingsPage: React.FC = () => {
  const { settings, updateSettings, canManageSettings, currentUser, setCurrentUser } = useData();

  // Local form state mirror of settings
  const [profileName, setProfileName] = useState(settings.profile.name);
  const [profileEmail, setProfileEmail] = useState(settings.profile.email);
  const [profileTitle, setProfileTitle] = useState(settings.profile.title);

  // Security
  const [twoFactor, setTwoFactor] = useState(settings.security.twoFactorEnabled);
  const [sessionTimeout, setSessionTimeout] = useState(settings.security.sessionTimeoutMinutes);
  const [passwordNotice, setPasswordNotice] = useState(false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');

  // Scanner
  const [entropyDetection, setEntropyDetection] = useState(settings.scanner.entropyDetection);
  const [confidenceThreshold, setConfidenceThreshold] = useState(settings.scanner.confidenceThreshold);
  const [defaultScanBehavior, setDefaultScanBehavior] = useState(settings.scanner.defaultScanBehavior);
  const [fileExclusions, setFileExclusions] = useState(settings.scanner.fileExclusions);
  const [ignoreTestFiles, setIgnoreTestFiles] = useState(settings.scanner.ignoreTestFiles);

  // Notifications
  const [criticalAlerts, setCriticalAlerts] = useState(settings.notifications.criticalAlerts);
  const [highRiskAlerts, setHighRiskAlerts] = useState(settings.notifications.highRiskAlerts);
  const [scanCompletionAlerts, setScanCompletionAlerts] = useState(settings.notifications.scanCompletionAlerts);
  const [complianceAlerts, setComplianceAlerts] = useState(settings.notifications.complianceAlerts);
  const [teamActivityAlerts, setTeamActivityAlerts] = useState(settings.notifications.teamActivityAlerts);

  // Repository
  const [defaultBranch, setDefaultBranch] = useState(settings.repository.defaultBranch);
  const [autoScanPref, setAutoScanPref] = useState(settings.repository.automaticScanPreference);
  const [scanFrequency, setScanFrequency] = useState(settings.repository.scanFrequency);

  // Appearance
  const [theme, setTheme] = useState(settings.appearance.theme);
  const [layout, setLayout] = useState(settings.appearance.layout);

  const [saveSuccess, setSaveSuccess] = useState(false);

  // Active sub-tab
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'scanner' | 'notifications' | 'repository' | 'appearance'>('profile');

  const handleSaveAll = (e: React.FormEvent) => {
    e.preventDefault();

    updateSettings({
      profile: {
        name: profileName,
        email: profileEmail,
        avatar: settings.profile.avatar,
        title: profileTitle,
      },
      security: {
        twoFactorEnabled: twoFactor,
        sessionTimeoutMinutes: Number(sessionTimeout),
        lastPasswordChange: passwordNotice ? new Date().toISOString().slice(0, 10) : settings.security.lastPasswordChange,
        enforceStrongPasswords: settings.security.enforceStrongPasswords,
      },
      scanner: {
        entropyDetection,
        confidenceThreshold: Number(confidenceThreshold),
        defaultScanBehavior,
        fileExclusions,
        ignoreTestFiles,
      },
      notifications: {
        criticalAlerts,
        highRiskAlerts,
        scanCompletionAlerts,
        complianceAlerts,
        teamActivityAlerts,
      },
      repository: {
        defaultBranch,
        automaticScanPreference: autoScanPref,
        scanFrequency,
      },
      appearance: {
        theme,
        layout,
      },
    });

    // Also update currentUser name/email
    setCurrentUser({
      ...currentUser,
      name: profileName,
      email: profileEmail,
    });

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
  };

  const handlePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!oldPassword || !newPassword) return;
    setPasswordNotice(true);
    setOldPassword('');
    setNewPassword('');
    setTimeout(() => setPasswordNotice(false), 3000);
  };

  return (
    <div id="settings-page" className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Shield className="w-5 h-5 text-cyan-400" />
            Scanner & System Settings
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure enterprise detection algorithms, scanning thresholds, notification channels, and user profile.
          </p>
        </div>

        <button
          id="save-settings-top-btn"
          onClick={handleSaveAll}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-950 transition"
        >
          {saveSuccess ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
          {saveSuccess ? 'Settings Saved to DB!' : 'Save All Changes'}
        </button>
      </div>

      {/* Tabs navigation */}
      <div className="flex items-center gap-1 border-b border-slate-800 overflow-x-auto pb-1">
        {[
          { id: 'profile', label: 'Profile', icon: User },
          { id: 'security', label: 'Security & Auth', icon: Lock },
          { id: 'scanner', label: 'Scanner Engine', icon: Scan },
          { id: 'notifications', label: 'Notifications', icon: Bell },
          { id: 'repository', label: 'Repository Defaults', icon: FolderGit2 },
          { id: 'appearance', label: 'Appearance', icon: Sun },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`settings-tab-${tab.id}`}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
                isActive
                  ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Form Content */}
      <form onSubmit={handleSaveAll} className="space-y-6">
        {/* TAB 1: PROFILE */}
        {activeTab === 'profile' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="text-sm font-bold text-slate-100 mb-1">User Profile</h3>
              <p className="text-xs text-slate-400">Personal information and active security lead identification.</p>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-16 h-16 rounded-full bg-cyan-950 border-2 border-cyan-500/40 text-cyan-300 flex items-center justify-center font-bold text-xl">
                {profileName.charAt(0)}
              </div>
              <div>
                <span className="text-xs font-semibold text-slate-200 block">{profileName}</span>
                <span className="text-[11px] text-cyan-400 font-mono block">{currentUser.role}</span>
                <span className="text-[11px] text-slate-400 mt-1 block">
                  Avatar initialized from enterprise directory.
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Full Name</label>
                <input
                  id="settings-profile-name"
                  type="text"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Corporate Email</label>
                <input
                  id="settings-profile-email"
                  type="email"
                  value={profileEmail}
                  onChange={(e) => setProfileEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-slate-300 font-semibold mb-1.5">Job Title</label>
                <input
                  id="settings-profile-title"
                  type="text"
                  value={profileTitle}
                  onChange={(e) => setProfileTitle(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: SECURITY */}
        {activeTab === 'security' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="text-sm font-bold text-slate-100 mb-1">Security & Authentication</h3>
              <p className="text-xs text-slate-400">Manage account authentication, active sessions, and multi-factor enforcement.</p>
            </div>

            {/* Session info */}
            <div className="bg-slate-950/70 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
              <h4 className="font-semibold text-slate-200 flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-cyan-400" />
                Active Session Security
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-slate-400">
                <div>
                  <span className="block text-[10px] text-slate-400">Client IP Address</span>
                  <span className="font-mono text-slate-200">192.168.1.104 (TLS 1.3)</span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400">Last Password Change</span>
                  <span className="font-mono text-slate-200">{settings.security.lastPasswordChange}</span>
                </div>
                <div>
                  <span className="block text-[10px] text-slate-400">Authorization Level</span>
                  <span className="font-mono text-cyan-400 font-bold">{currentUser.role}</span>
                </div>
              </div>
            </div>

            {/* Toggles */}
            <div className="space-y-3 pt-2 text-xs">
              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-950/40 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-slate-200 block">Enforce Two-Factor Authentication (2FA)</span>
                  <span className="text-[11px] text-slate-400">Require hardware security key or authenticator app.</span>
                </div>
                <input
                  id="settings-2fa-toggle"
                  type="checkbox"
                  checked={twoFactor}
                  onChange={(e) => setTwoFactor(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
              </label>

              <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-200 block">Session Inactivity Timeout</span>
                  <span className="text-[11px] text-slate-400">Automatically lock console after idle duration.</span>
                </div>
                <select
                  id="settings-session-timeout"
                  value={sessionTimeout}
                  onChange={(e) => setSessionTimeout(Number(e.target.value))}
                  className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-cyan-500"
                >
                  <option value={15}>15 Minutes</option>
                  <option value={30}>30 Minutes</option>
                  <option value={60}>60 Minutes</option>
                  <option value={120}>2 Hours</option>
                </select>
              </div>
            </div>

            {/* Change Password Box */}
            <div className="pt-4 border-t border-slate-800">
              <h4 className="text-xs font-semibold text-slate-200 mb-3">Change Account Password</h4>
              {passwordNotice && (
                <div className="mb-3 text-xs text-emerald-400 bg-emerald-950/30 border border-emerald-900/40 p-2.5 rounded-lg flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  Password credentials updated and encrypted in secure store.
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <input
                  id="settings-old-password"
                  type="password"
                  placeholder="Current Password"
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                />
                <input
                  id="settings-new-password"
                  type="password"
                  placeholder="New Secure Password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 focus:outline-hidden focus:border-cyan-500"
                />
              </div>
              <button
                type="button"
                onClick={handlePasswordSubmit}
                disabled={!oldPassword || !newPassword}
                className="mt-3 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium border border-slate-700 disabled:opacity-40"
              >
                Update Password
              </button>
            </div>
          </div>
        )}

        {/* TAB 3: SCANNER SETTINGS */}
        {activeTab === 'scanner' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="text-sm font-bold text-slate-100 mb-1">Scanner Engine Configuration</h3>
              <p className="text-xs text-slate-400">
                Tweak Shannon entropy evaluation, detection thresholds, and exclusion rules.
              </p>
            </div>

            <div className="space-y-4 text-xs">
              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-slate-200 block">
                    Shannon Entropy Analysis (H &gt; 4.2 bits/char)
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Flag pseudorandom cryptographic keys, tokens, and hashes without rigid regex patterns.
                  </span>
                </div>
                <input
                  id="settings-entropy-toggle"
                  type="checkbox"
                  checked={entropyDetection}
                  onChange={(e) => setEntropyDetection(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-slate-200 block">Ignore Test & Demo Files</span>
                  <span className="text-[11px] text-slate-400">
                    Suppress findings in files matching `__tests__`, `.spec.`, or test mock fixtures.
                  </span>
                </div>
                <input
                  id="settings-ignore-test-toggle"
                  type="checkbox"
                  checked={ignoreTestFiles}
                  onChange={(e) => setIgnoreTestFiles(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
              </label>

              {/* Slider for confidence */}
              <div className="p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-200 block">Confidence Threshold</span>
                    <span className="text-[11px] text-slate-400">
                      Minimum certainty score required to trigger an alert.
                    </span>
                  </div>
                  <span className="text-sm font-bold font-mono text-cyan-400">{confidenceThreshold}%</span>
                </div>
                <input
                  id="settings-confidence-slider"
                  type="range"
                  min={50}
                  max={99}
                  value={confidenceThreshold}
                  onChange={(e) => setConfidenceThreshold(Number(e.target.value))}
                  className="w-full accent-cyan-500"
                />
              </div>

              {/* Default Scan Behavior */}
              <div className="p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-semibold text-slate-200 block">Default Scan Depth</span>
                  <span className="text-[11px] text-slate-400">
                    Determines history inspection depth on triggered scans.
                  </span>
                </div>
                <select
                  id="settings-scan-behavior"
                  value={defaultScanBehavior}
                  onChange={(e) => setDefaultScanBehavior(e.target.value as any)}
                  className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-cyan-500"
                >
                  <option value="deep">Deep (Full Git History & Diffs)</option>
                  <option value="incremental">Incremental (Latest Commits Only)</option>
                  <option value="fast">Fast (HEAD Working Tree Only)</option>
                </select>
              </div>

              {/* Exclusion patterns */}
              <div className="space-y-1.5">
                <label className="block text-slate-300 font-semibold">File Exclusion Patterns (Glob)</label>
                <input
                  id="settings-file-exclusions"
                  type="text"
                  value={fileExclusions}
                  onChange={(e) => setFileExclusions(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 font-mono text-xs focus:outline-hidden focus:border-cyan-500"
                />
                <span className="text-[11px] text-slate-400">
                  Comma-separated globs ignored by both pre-commit and pipeline scans.
                </span>
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: NOTIFICATIONS */}
        {activeTab === 'notifications' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="text-sm font-bold text-slate-100 mb-1">Alert Notification Preferences</h3>
              <p className="text-xs text-slate-400">Control which security events trigger in-app and email notifications.</p>
            </div>

            <div className="space-y-3 text-xs">
              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-rose-400 block">Critical Finding Alerts</span>
                  <span className="text-[11px] text-slate-400">Dispatches instant alert when high-impact live keys are discovered.</span>
                </div>
                <input
                  id="notif-critical-toggle"
                  type="checkbox"
                  checked={criticalAlerts}
                  onChange={(e) => setCriticalAlerts(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-amber-400 block">High-Risk Finding Alerts</span>
                  <span className="text-[11px] text-slate-400">Notifies when API tokens or webhook secrets are exposed.</span>
                </div>
                <input
                  id="notif-high-toggle"
                  type="checkbox"
                  checked={highRiskAlerts}
                  onChange={(e) => setHighRiskAlerts(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-slate-200 block">Scan Completion Alerts</span>
                  <span className="text-[11px] text-slate-400">Receive summaries when scheduled or CI/CD scans finish.</span>
                </div>
                <input
                  id="notif-scan-toggle"
                  type="checkbox"
                  checked={scanCompletionAlerts}
                  onChange={(e) => setScanCompletionAlerts(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-slate-200 block">Compliance Benchmark Alerts</span>
                  <span className="text-[11px] text-slate-400">Notifies when the organization security compliance score changes.</span>
                </div>
                <input
                  id="notif-compliance-toggle"
                  type="checkbox"
                  checked={complianceAlerts}
                  onChange={(e) => setComplianceAlerts(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3.5 rounded-xl bg-slate-950/50 border border-slate-800 cursor-pointer">
                <div>
                  <span className="font-semibold text-slate-200 block">Team Activity Alerts</span>
                  <span className="text-[11px] text-slate-400">Alerts when new team members are added or permissions change.</span>
                </div>
                <input
                  id="notif-team-toggle"
                  type="checkbox"
                  checked={teamActivityAlerts}
                  onChange={(e) => setTeamActivityAlerts(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
              </label>
            </div>
          </div>
        )}

        {/* TAB 5: REPOSITORY DEFAULTS */}
        {activeTab === 'repository' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="text-sm font-bold text-slate-100 mb-1">Repository Scanning Policy</h3>
              <p className="text-xs text-slate-400">Default settings applied to newly enrolled repositories.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Default Branch Name</label>
                <input
                  id="settings-default-branch"
                  type="text"
                  value={defaultBranch}
                  onChange={(e) => setDefaultBranch(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 font-mono text-xs focus:outline-hidden focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Automatic Scan Preference</label>
                <select
                  id="settings-auto-scan-pref"
                  value={autoScanPref}
                  onChange={(e) => setAutoScanPref(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-cyan-500"
                >
                  <option value="push">On Every Git Push</option>
                  <option value="nightly">Nightly Cron</option>
                  <option value="manual">Manual Trigger Only</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1.5">Scan Cadence</label>
                <select
                  id="settings-scan-frequency"
                  value={scanFrequency}
                  onChange={(e) => setScanFrequency(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-slate-200 text-xs focus:outline-hidden focus:border-cyan-500"
                >
                  <option value="continuous">Continuous Webhooks</option>
                  <option value="daily">Daily Sweep</option>
                  <option value="weekly">Weekly Deep Audit</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: APPEARANCE */}
        {activeTab === 'appearance' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6 animate-in fade-in duration-150">
            <div>
              <h3 className="text-sm font-bold text-slate-100 mb-1">Visual Theme & Layout</h3>
              <p className="text-xs text-slate-400">Choose your preferred workspace aesthetic and dashboard density.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Dark mode selector */}
              <div
                id="theme-dark-option"
                onClick={() => setTheme('dark')}
                className={`p-4 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                  theme === 'dark'
                    ? 'bg-slate-950 border-cyan-500 text-slate-100 ring-1 ring-cyan-500'
                    : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Moon className="w-5 h-5 text-cyan-400" />
                  <div>
                    <span className="text-xs font-bold block">Dark Mode (Security SOC Style)</span>
                    <span className="text-[11px] text-slate-400">Optimized for high-contrast security monitoring</span>
                  </div>
                </div>
                {theme === 'dark' && <Check className="w-4 h-4 text-cyan-400" />}
              </div>

              {/* Light mode selector */}
              <div
                id="theme-light-option"
                onClick={() => setTheme('light')}
                className={`p-4 rounded-xl border cursor-pointer transition flex items-center justify-between ${
                  theme === 'light'
                    ? 'bg-slate-800 border-cyan-500 text-slate-100 ring-1 ring-cyan-500'
                    : 'bg-slate-950/40 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Sun className="w-5 h-5 text-amber-400" />
                  <div>
                    <span className="text-xs font-bold block">Light Theme</span>
                    <span className="text-[11px] text-slate-400">Clean high-visibility daylight palette</span>
                  </div>
                </div>
                {theme === 'light' && <Check className="w-4 h-4 text-cyan-400" />}
              </div>
            </div>

            {/* Layout density */}
            <div className="pt-2">
              <h4 className="text-xs font-semibold text-slate-300 mb-2">Dashboard Density</h4>
              <div className="flex items-center gap-3 text-xs">
                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="radio"
                    name="layoutDensity"
                    value="comfortable"
                    checked={layout === 'comfortable'}
                    onChange={() => setLayout('comfortable')}
                    className="accent-cyan-500"
                  />
                  <span>Comfortable (Spacious spacing)</span>
                </label>
                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="radio"
                    name="layoutDensity"
                    value="compact"
                    checked={layout === 'compact'}
                    onChange={() => setLayout('compact')}
                    className="accent-cyan-500"
                  />
                  <span>Compact (High data density)</span>
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Save Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          <span className="text-xs text-slate-400">
            {saveSuccess ? (
              <span className="text-emerald-400 font-semibold flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> All settings successfully saved to database.
              </span>
            ) : (
              'Changes will persist across browser reloads.'
            )}
          </span>

          <button
            id="save-settings-bottom-btn"
            type="submit"
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-md shadow-cyan-950 transition"
          >
            <Save className="w-4 h-4" />
            Save All Changes
          </button>
        </div>
      </form>
    </div>
  );
};

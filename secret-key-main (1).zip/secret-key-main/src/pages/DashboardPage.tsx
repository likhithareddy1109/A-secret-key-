import React, { useState } from 'react';
import {
  Activity,
  AlertOctagon,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  Clock,
  ExternalLink,
  Eye,
  FolderGit2,
  Play,
  RotateCcw,
  Shield,
  ShieldAlert,
  ShieldCheck,
  Terminal,
  TrendingDown,
  TrendingUp,
  Users,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { FindingDetailModal } from '../components/FindingDetailModal';
import { RiskBadge } from '../components/RiskBadge';
import { StatusBadge } from '../components/StatusBadge';
import { useData } from '../context/DataContext';
import { SecretFinding } from '../types';

interface DashboardPageProps {
  onNavigate: (page: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const {
    complianceMetrics,
    findings,
    repositories,
    scans,
    notifications,
    triggerScan,
    updateFindingStatus,
    canResolveFindings,
    canTriggerScan,
  } = useData();

  const [activeFinding, setActiveFinding] = useState<SecretFinding | null>(null);
  const [isScanningRepo, setIsScanningRepo] = useState<string | null>(null);

  // Quick scan trigger from dashboard
  const handleQuickScan = async (repoId: string) => {
    setIsScanningRepo(repoId);
    try {
      await triggerScan(repoId, 'Manual trigger');
    } finally {
      setIsScanningRepo(null);
    }
  };

  // 5 most recent critical or high findings
  const recentCriticalFindings = findings
    .filter((f) => f.riskLevel === 'Critical' || f.riskLevel === 'High')
    .slice(0, 5);

  // Risk distribution data
  const riskCounts = {
    Critical: findings.filter((f) => f.riskLevel === 'Critical' && f.status !== 'Resolved' && f.status !== 'False Positive').length,
    High: findings.filter((f) => f.riskLevel === 'High' && f.status !== 'Resolved' && f.status !== 'False Positive').length,
    Medium: findings.filter((f) => f.riskLevel === 'Medium' && f.status !== 'Resolved' && f.status !== 'False Positive').length,
    Low: findings.filter((f) => f.riskLevel === 'Low' && f.status !== 'Resolved' && f.status !== 'False Positive').length,
  };

  const riskPieData = [
    { name: 'Critical', value: riskCounts.Critical, color: '#f43f5e' },
    { name: 'High', value: riskCounts.High, color: '#f59e0b' },
    { name: 'Medium', value: riskCounts.Medium, color: '#eab308' },
    { name: 'Low', value: riskCounts.Low, color: '#38bdf8' },
  ];

  // Scan activity over recent scans
  const scanTimelineData = scans.slice(0, 7).reverse().map((s, idx) => ({
    time: s.scannedAt.split(' ')[1] || `S-${idx + 1}`,
    findings: s.findingsDetected,
    files: s.filesScanned,
  }));

  return (
    <div id="dashboard-page" className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4" />
            Active Continuous Guard
          </span>
          <h2 className="text-xl font-bold text-slate-100 mt-1">
            Enterprise Secret Leak Defense Center
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated monitoring across {repositories.length} repositories. Zero raw credentials stored.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {repositories.length > 0 && (
            <button
              id="dashboard-quick-scan-btn"
              onClick={() => handleQuickScan(repositories[0].id)}
              disabled={!canTriggerScan || !!isScanningRepo}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold shadow-sm transition disabled:opacity-50"
            >
              {isScanningRepo ? (
                <>
                  <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                  Scanning...
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  Run Fast Scan ({repositories[0].name})
                </>
              )}
            </button>
          )}

          <button
            id="dashboard-test-hook-btn"
            onClick={() => onNavigate('developer-tools')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition"
          >
            <Terminal className="w-3.5 h-3.5 text-cyan-400" />
            Developer Tools
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Compliance Score */}
        <div
          id="kpi-compliance-score"
          onClick={() => onNavigate('compliance')}
          className="bg-slate-900 border border-slate-800 hover:border-cyan-500/50 rounded-2xl p-5 shadow-lg cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span className="font-semibold uppercase tracking-wider text-[11px]">Security Score</span>
            <span
              className={`inline-flex items-center gap-0.5 text-xs font-bold font-mono px-2 py-0.5 rounded-full ${
                complianceMetrics.change >= 0
                  ? 'bg-emerald-500/15 text-emerald-400'
                  : 'bg-rose-500/15 text-rose-400'
              }`}
            >
              {complianceMetrics.change >= 0 ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              {complianceMetrics.change >= 0 ? `+${complianceMetrics.change}%` : `${complianceMetrics.change}%`}
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <div className="text-3xl font-black font-mono text-cyan-400 group-hover:text-cyan-300">
              {complianceMetrics.score}%
            </div>
            <ShieldCheck className="w-6 h-6 text-cyan-500/40 group-hover:text-cyan-400 transition" />
          </div>
          <p className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>Coverage: {complianceMetrics.scanCoveragePercent}% repos</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300" />
          </p>
        </div>

        {/* KPI 2: Open Findings */}
        <div
          id="kpi-open-findings"
          onClick={() => onNavigate('findings')}
          className="bg-slate-900 border border-slate-800 hover:border-rose-500/50 rounded-2xl p-5 shadow-lg cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span className="font-semibold uppercase tracking-wider text-[11px]">Open Findings</span>
            <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded font-mono font-bold">
              {complianceMetrics.criticalFindings} Critical
            </span>
          </div>
          <div className="flex items-baseline justify-between">
            <div className="text-3xl font-black font-mono text-rose-400 group-hover:text-rose-300">
              {complianceMetrics.openFindings}
            </div>
            <ShieldAlert className="w-6 h-6 text-rose-500/40 group-hover:text-rose-400 transition" />
          </div>
          <p className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>{complianceMetrics.highFindings} High • {complianceMetrics.resolvedFindings} Resolved</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300" />
          </p>
        </div>

        {/* KPI 3: Monitored Repositories */}
        <div
          id="kpi-repositories"
          onClick={() => onNavigate('repositories')}
          className="bg-slate-900 border border-slate-800 hover:border-blue-500/50 rounded-2xl p-5 shadow-lg cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span className="font-semibold uppercase tracking-wider text-[11px]">Repositories</span>
            <span className="text-[10px] text-emerald-400 font-mono">100% Active</span>
          </div>
          <div className="flex items-baseline justify-between">
            <div className="text-3xl font-black font-mono text-slate-100 group-hover:text-blue-300">
              {repositories.length}
            </div>
            <FolderGit2 className="w-6 h-6 text-blue-500/40 group-hover:text-blue-400 transition" />
          </div>
          <p className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>Total scans: {scans.length}</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300" />
          </p>
        </div>

        {/* KPI 4: Remediated / Clean Ratio */}
        <div
          id="kpi-remediated"
          onClick={() => onNavigate('findings')}
          className="bg-slate-900 border border-slate-800 hover:border-emerald-500/50 rounded-2xl p-5 shadow-lg cursor-pointer transition group"
        >
          <div className="flex items-center justify-between text-slate-400 text-xs mb-2">
            <span className="font-semibold uppercase tracking-wider text-[11px]">Remediated Leaks</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline justify-between">
            <div className="text-3xl font-black font-mono text-emerald-400 group-hover:text-emerald-300">
              {complianceMetrics.resolvedFindings}
            </div>
            <span className="text-xs font-mono text-slate-400">
              of {findings.length} total
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-2 flex items-center justify-between">
            <span>Clean scans: {complianceMetrics.cleanScans}</span>
            <ChevronRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-300" />
          </p>
        </div>
      </div>

      {/* Analytics & Distribution Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Risk Distribution Chart */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Shield className="w-4 h-4 text-rose-400" />
              Active Exposure Risk Breakdown
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              {complianceMetrics.openFindings} Open
            </span>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Distribution of pending leaks requiring immediate key rotation
          </p>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={riskPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {riskPieData.map((entry, index) => (
                    <Cell key={`cell-risk-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    color: '#f8fafc',
                    fontSize: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-4 gap-2 pt-2 border-t border-slate-800 text-center">
            <div>
              <span className="text-rose-400 font-bold font-mono text-sm">{riskCounts.Critical}</span>
              <span className="text-[10px] text-slate-400 block">Critical</span>
            </div>
            <div>
              <span className="text-amber-400 font-bold font-mono text-sm">{riskCounts.High}</span>
              <span className="text-[10px] text-slate-400 block">High</span>
            </div>
            <div>
              <span className="text-yellow-400 font-bold font-mono text-sm">{riskCounts.Medium}</span>
              <span className="text-[10px] text-slate-400 block">Medium</span>
            </div>
            <div>
              <span className="text-blue-400 font-bold font-mono text-sm">{riskCounts.Low}</span>
              <span className="text-[10px] text-slate-400 block">Low</span>
            </div>
          </div>
        </div>

        {/* Scan Activity Timeline */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              Recent Scan Findings Activity
            </h3>
            <button
              onClick={() => onNavigate('scans')}
              className="text-xs text-cyan-400 hover:underline flex items-center gap-1"
            >
              View Scans <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Findings flagged across recent automated inspection runs
          </p>

          <div className="h-52 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={scanTimelineData}>
                <defs>
                  <linearGradient id="scanGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748b" fontSize={10} />
                <YAxis stroke="#64748b" fontSize={10} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    color: '#f8fafc',
                    fontSize: '12px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="findings"
                  name="Detected Secrets"
                  stroke="#06b6d4"
                  fillOpacity={1}
                  fill="url(#scanGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800">
            <span>Last Scan: {scans[0]?.scannedAt || 'Just now'}</span>
            <span className="font-mono text-emerald-400">Continuous CI Protection Online</span>
          </div>
        </div>
      </div>

      {/* Recent High Priority Findings */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
          <div>
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              Urgent Critical & High Leaks
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Top priority credentials requiring revocation and rotation
            </p>
          </div>

          <button
            id="view-all-findings-btn"
            onClick={() => onNavigate('findings')}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
          >
            All Findings ({findings.length}) <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/60 text-slate-400 text-[11px] uppercase tracking-wider">
                <th className="py-3 px-4">Finding ID</th>
                <th className="py-3 px-4">Repository</th>
                <th className="py-3 px-4">Secret Type</th>
                <th className="py-3 px-4">Masked Preview</th>
                <th className="py-3 px-4">Risk</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {recentCriticalFindings.map((finding) => (
                <tr
                  key={finding.id}
                  onClick={() => setActiveFinding(finding)}
                  className="hover:bg-slate-800/50 cursor-pointer transition"
                >
                  <td className="py-3 px-4 font-mono font-bold text-cyan-400 whitespace-nowrap">
                    {finding.id}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-300 whitespace-nowrap">
                    {finding.repoName}
                  </td>
                  <td className="py-3 px-4 text-slate-200 font-medium whitespace-nowrap">
                    {finding.secretType}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-400 whitespace-nowrap">
                    {finding.maskedPreview}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <RiskBadge level={finding.riskLevel} />
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    <StatusBadge status={finding.status} />
                  </td>
                  <td
                    className="py-3 px-4 text-right whitespace-nowrap"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => setActiveFinding(finding)}
                        className="p-1.5 text-slate-400 hover:text-cyan-300 rounded hover:bg-slate-800"
                        title="View Finding Details"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>

                      {finding.status !== 'Resolved' && (
                        <button
                          onClick={() => updateFindingStatus(finding.id, 'Resolved')}
                          disabled={!canResolveFindings}
                          className="px-2 py-1 rounded text-xs font-semibold bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 transition disabled:opacity-30"
                          title="Resolve Finding"
                        >
                          Resolve
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Monitored Repositories & Activity Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monitored Repositories overview */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <FolderGit2 className="w-4 h-4 text-cyan-400" />
              Monitored Repositories Health
            </h3>
            <button
              onClick={() => onNavigate('repositories')}
              className="text-xs text-cyan-400 hover:underline"
            >
              Manage
            </button>
          </div>

          <div className="space-y-3">
            {repositories.map((repo) => (
              <div
                key={repo.id}
                className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-semibold text-slate-200 font-mono flex items-center gap-2">
                    {repo.name}
                    <span className="text-[10px] text-slate-400 font-normal px-1.5 py-0.2 rounded bg-slate-900 border border-slate-800">
                      {repo.language}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Last scan: {repo.lastScanDate} • {repo.totalScans} scans completed
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span
                      className={`font-mono font-bold ${
                        repo.healthScore >= 85
                          ? 'text-emerald-400'
                          : repo.healthScore >= 70
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {repo.healthScore}%
                    </span>
                    <span className="block text-[10px] text-slate-400">Score</span>
                  </div>

                  <button
                    onClick={() => handleQuickScan(repo.id)}
                    disabled={!canTriggerScan || isScanningRepo === repo.id}
                    className="p-1.5 rounded-lg bg-slate-900 hover:bg-cyan-950/40 text-slate-300 hover:text-cyan-400 border border-slate-800 transition disabled:opacity-40"
                    title="Run quick scan on this repository"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Security Alerts Activity */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-bold text-slate-100 flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              Live Security Event Stream
            </h3>
            <button
              onClick={() => onNavigate('notifications')}
              className="text-xs text-cyan-400 hover:underline"
            >
              All Alerts
            </button>
          </div>

          <div className="space-y-3">
            {notifications.slice(0, 4).map((notif) => (
              <div
                key={notif.id}
                className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 text-xs flex items-start gap-3"
              >
                <div className="p-1.5 rounded-md bg-slate-900 border border-slate-800 shrink-0 mt-0.5">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                </div>
                <div className="flex-1 space-y-0.5">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">{notif.title}</span>
                    <span className="text-[10px] font-mono text-slate-400">{notif.timestamp}</span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-tight line-clamp-2">
                    {notif.message}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Modal */}
      {activeFinding && (
        <FindingDetailModal finding={activeFinding} onClose={() => setActiveFinding(null)} />
      )}
    </div>
  );
};
